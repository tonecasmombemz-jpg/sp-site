<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Architecture decisions
- Client-reachable server functions live in `src/lib/*.ts` (`study-data.ts`, `public-data.ts`) — never inside a `server/` directory: the import-protection plugin denies `**/server/**` imports in the client environment (dev server and browser break, build may stay green).
- Server-only helpers (admin client, answer key, AI responses) are loaded with dynamic `await import(...)` inside server-function handler bodies; answer keys (`question_alternatives.is_correct`) are never exposed to the browser — grading happens server-side, except client-side grading for `is_demo` exams.
- Parent route files (`disciplinas.tsx`, `simulados.tsx`) are layouts rendering `<Outlet />`; their list pages live in `*.index.tsx` siblings.
- Auth-protected pages live under `src/routes/_authenticated/` (pathless layout redirects to `/entrar`); sign-up creates `public.profiles` via the `on_auth_user_created` trigger.
