import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import {
  ArrowLeft, ArrowRight, CheckCircle2, Loader2, Timer, Trophy, XCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useSession } from "@/hooks/use-session";
import {
  getExamQuestions,
  getExamQuestionsForUser,
  submitExamAttempt,
  type ExamDetail,
  type ExamQuestionView,
  type ExamResult,
  type ExamResultItem,
} from "@/lib/study-data";

export const Route = createFileRoute("/simulados/$examId")({
  loader: async ({ params }) => {
    const data = await getExamQuestions({ data: params.examId });
    if (!data) throw notFound();
    return data;
  },
  head: () => ({
    meta: [
      { title: "Simulado — SUPER PROFS" },
      {
        name: "description",
        content: "Resolve este simulado com perguntas de escolha múltipla e recebe a correcção automática.",
      },
      { property: "og:title", content: "Simulado — SUPER PROFS" },
      {
        property: "og:description",
        content: "Simulado com perguntas de escolha múltipla e correcção automática.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SimuladoPage,
});

type Phase = "intro" | "running" | "results";

function formatTime(totalSeconds: number): string {
  const m = Math.floor(totalSeconds / 60);
  const s = totalSeconds % 60;
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

function SimuladoPage() {
  const initial = Route.useLoaderData();
  const exam: ExamDetail = initial.exam;
  const { user } = useSession();

  const questionsForUserFn = useServerFn(getExamQuestionsForUser);
  const submitFn = useServerFn(submitExamAttempt);

  const [phase, setPhase] = useState<Phase>("intro");
  const [premiumLocked, setPremiumLocked] = useState(false);
  const [questions, setQuestions] = useState<ExamQuestionView[]>(initial.questions);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [current, setCurrent] = useState(0);
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [result, setResult] = useState<ExamResult | null>(null);

  const guestAllowed = exam.is_demo;

  const startExam = async () => {
    if (user) {
      const r = await questionsForUserFn({ data: exam.id });
      if (!r) {
        toast.error("Este simulado já não está disponível.");
        return;
      }
      if (!r.allowed) {
        setPremiumLocked(true);
        return;
      }
      setQuestions(r.questions);
    } else if (!guestAllowed) {
      return;
    }
    setAnswers({});
    setCurrent(0);
    setResult(null);
    setSecondsLeft(exam.duration_minutes ? exam.duration_minutes * 60 : null);
    setPhase("running");
  };

  const handleSubmit = async () => {
    if (submitting) return;
    setSubmitting(true);
    try {
      const answered = Object.entries(answers)
        .filter(([, alternativeId]) => !!alternativeId)
        .map(([questionId, alternativeId]) => ({ questionId, alternativeId }));

      if (user) {
        const r = await submitFn({ data: { examId: exam.id, answers: answered } });
        if ("error" in r) {
          toast.error(r.error);
          return;
        }
        setResult(r);
      } else {
        // Demonstração sem conta: correcção feita no próprio dispositivo.
        const items: ExamResultItem[] = questions.map((q) => {
          const selectedId = answers[q.id] ?? null;
          const isCorrect = !!selectedId && selectedId === q.correct_alternative_id;
          const selected = q.alternatives.find((a) => a.id === selectedId) ?? null;
          const correct = q.alternatives.find((a) => a.id === q.correct_alternative_id) ?? null;
          return {
            questionId: q.id,
            statement: q.statement,
            selectedId,
            selectedContent: selected?.content ?? null,
            correctId: q.correct_alternative_id ?? null,
            correctContent: correct?.content ?? null,
            isCorrect,
            explanation: q.explanation,
          };
        });
        const total = items.length;
        const correctCount = items.filter((i) => i.isCorrect).length;
        setResult({
          total,
          correctCount,
          scorePercent: total ? Math.round((correctCount / total) * 100) : 0,
          items,
        });
      }
      setPhase("results");
    } catch {
      toast.error("Não foi possível entregar o simulado. Tenta novamente.");
    } finally {
      setSubmitting(false);
    }
  };

  // Temporizador
  useEffect(() => {
    if (phase !== "running" || secondsLeft === null) return;
    if (secondsLeft <= 0) return;
    const t = setTimeout(() => setSecondsLeft((s) => (s === null ? null : s - 1)), 1000);
    return () => clearTimeout(t);
  }, [phase, secondsLeft]);

  useEffect(() => {
    if (phase === "running" && secondsLeft === 0 && !submitting) {
      void handleSubmit();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [secondsLeft, phase]);

  const question = questions[current];
  const answeredCount = Object.values(answers).filter(Boolean).length;

  // ============= Resultados =============
  if (phase === "results" && result) {
    return (
      <div className="container-page max-w-3xl py-8 md:py-12">
        <Card className="text-center shadow-card">
          <CardHeader>
            <Trophy className="mx-auto h-10 w-10 text-brand" />
            <CardTitle className="font-display text-2xl">Resultado do simulado</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-display text-5xl font-bold text-navy">{result.scorePercent}%</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Acertaste {result.correctCount} de {result.total} perguntas em {exam.title}.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Button
                onClick={() => {
                  setPhase("intro");
                  setAnswers({});
                  setCurrent(0);
                  setResult(null);
                  setPremiumLocked(false);
                }}
                variant="outline"
              >
                Repetir
              </Button>
              <Button asChild>
                <Link to="/simulados">Outros simulados</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        <h2 className="mt-10 font-display text-xl font-bold">Revisão das respostas</h2>
        <div className="mt-4 flex flex-col gap-4">
          {result.items.map((item, i) => (
            <Card key={item.questionId} className="shadow-card">
              <CardHeader>
                <div className="flex items-center justify-between gap-2">
                  <Badge variant="secondary">Pergunta {i + 1}</Badge>
                  {item.isCorrect ? (
                    <Badge className="gap-1 border-transparent bg-primary/10 text-primary">
                      <CheckCircle2 className="h-3.5 w-3.5" /> Correcta
                    </Badge>
                  ) : (
                    <Badge className="gap-1 border-transparent bg-destructive/10 text-destructive">
                      <XCircle className="h-3.5 w-3.5" /> Incorrecta
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-base leading-relaxed">{item.statement}</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-2 text-sm">
                {item.selectedContent ? (
                  <p className={item.isCorrect ? "text-primary" : "text-destructive"}>
                    Tua resposta: {item.selectedContent}
                  </p>
                ) : (
                  <p className="text-muted-foreground">Sem resposta.</p>
                )}
                {!item.isCorrect && item.correctContent && (
                  <p className="text-primary">Resposta certa: {item.correctContent}</p>
                )}
                {item.explanation && (
                  <p className="leading-relaxed text-muted-foreground">{item.explanation}</p>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  // ============= Em execução =============
  if (phase === "running" && question) {
    return (
      <div className="container-page max-w-3xl py-8 md:py-12">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <Link
            to="/simulados"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
          >
            <ArrowLeft className="h-4 w-4" /> Sair do simulado
          </Link>
          <div className="flex items-center gap-2">
            {secondsLeft !== null && (
              <Badge
                variant="outline"
                className={secondsLeft < 60 ? "border-destructive text-destructive" : ""}
              >
                <Timer className="mr-1.5 h-3.5 w-3.5" /> {formatTime(secondsLeft)}
              </Badge>
            )}
            <Badge variant="secondary">
              Pergunta {current + 1} de {questions.length}
            </Badge>
          </div>
        </div>

        <Card className="mt-6 shadow-card">
          <CardHeader>
            <CardTitle className="text-lg leading-relaxed">{question.statement}</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-col gap-2.5">
            {question.alternatives.map((alt) => {
              const isSelected = answers[question.id] === alt.id;
              return (
                <button
                  key={alt.id}
                  type="button"
                  onClick={() => setAnswers((a) => ({ ...a, [question.id]: alt.id }))}
                  className={`rounded-lg border px-4 py-3 text-left text-sm transition-colors ${
                    isSelected
                      ? "border-primary bg-primary/10 font-medium text-primary"
                      : "border-border bg-background hover:bg-secondary"
                  }`}
                >
                  {alt.content}
                </button>
              );
            })}
          </CardContent>
        </Card>

        <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
          <Button
            variant="outline"
            disabled={current === 0}
            onClick={() => setCurrent((c) => Math.max(0, c - 1))}
            className="gap-2"
          >
            <ArrowLeft className="h-4 w-4" /> Anterior
          </Button>
          <div className="flex flex-wrap justify-center gap-1.5" aria-label="Navegação por pergunta">
            {questions.map((q, i) => (
              <button
                key={q.id}
                type="button"
                aria-label={`Ir para a pergunta ${i + 1}`}
                onClick={() => setCurrent(i)}
                className={`h-8 w-8 rounded-md border text-xs font-medium transition-colors ${
                  i === current
                    ? "border-primary bg-primary text-primary-foreground"
                    : answers[q.id]
                      ? "border-primary/40 bg-primary/10 text-primary"
                      : "border-border text-muted-foreground hover:bg-secondary"
                }`}
              >
                {i + 1}
              </button>
            ))}
          </div>
          {current + 1 < questions.length ? (
            <Button onClick={() => setCurrent((c) => Math.min(questions.length - 1, c + 1))} className="gap-2">
              Seguinte <ArrowRight className="h-4 w-4" />
            </Button>
          ) : (
            <Button onClick={handleSubmit} disabled={submitting} className="gap-2">
              {submitting ? <Loader2 className="h-4 w-4 animate-spin" /> : <CheckCircle2 className="h-4 w-4" />}
              Entregar
            </Button>
          )}
        </div>

        <p className="mt-4 text-center text-xs text-muted-foreground">
          Respondidas: {answeredCount} de {questions.length}
          {answeredCount < questions.length && " — podes entregar mesmo com perguntas sem resposta."}
        </p>
      </div>
    );
  }

  // ============= Ecrã inicial =============
  return (
    <div className="container-page max-w-2xl py-10 md:py-16">
      <Link
        to="/simulados"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Todos os simulados
      </Link>

      <Card className="mt-4 shadow-card">
        <CardHeader>
          <div className="flex flex-wrap items-center gap-2">
            {exam.is_demo && <Badge variant="secondary">Demonstração</Badge>}
            {exam.is_premium && <Badge className="bg-brand text-navy">Premium</Badge>}
            {exam.discipline_name && <Badge variant="outline">{exam.discipline_name}</Badge>}
          </div>
          <CardTitle className="font-display text-2xl">{exam.title}</CardTitle>
          <p className="text-sm text-muted-foreground">{exam.description}</p>
        </CardHeader>
        <CardContent className="flex flex-col gap-4">
          <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="h-4 w-4 text-brand" /> {initial.questions.length} perguntas de escolha múltipla
            </span>
            {exam.duration_minutes ? (
              <span className="flex items-center gap-1.5">
                <Timer className="h-4 w-4 text-brand" /> {exam.duration_minutes} minutos
              </span>
            ) : (
              <span className="flex items-center gap-1.5">
                <Timer className="h-4 w-4 text-brand" /> Sem limite de tempo
              </span>
            )}
          </div>

          {premiumLocked ? (
            <div className="rounded-lg border border-brand/40 bg-secondary/40 p-4">
              <p className="text-sm font-medium">Este simulado é premium.</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Subscreve um plano para desbloquear todos os simulados completos.
              </p>
              <Button asChild className="mt-3 bg-brand text-navy hover:bg-brand/90">
                <Link to="/planos">Ver planos</Link>
              </Button>
            </div>
          ) : user || guestAllowed ? (
            <Button size="lg" onClick={startExam}>
              Começar o simulado
            </Button>
          ) : (
            <div className="rounded-lg border border-border bg-secondary/40 p-4">
              <p className="text-sm font-medium">Entra para resolver este simulado.</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Com uma conta gratuita o teu progresso fica guardado e recebes o resultado completo.
              </p>
              <div className="mt-3 flex flex-wrap gap-2">
                <Button asChild>
                  <Link to="/entrar">Entrar</Link>
                </Button>
                <Button asChild variant="outline">
                  <Link to="/registar">Criar conta grátis</Link>
                </Button>
              </div>
            </div>
          )}

          {!user && guestAllowed && (
            <p className="text-xs text-muted-foreground">
              Demonstração: podes experimentar sem conta, mas o resultado não fica guardado.
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
