import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Video } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getPublishedVideos } from "@/lib/public-data";

const videosOptions = queryOptions({
  queryKey: ["videos"],
  queryFn: () => getPublishedVideos(),
});

export const Route = createFileRoute("/videos")({
  loader: ({ context }) => context.queryClient.ensureQueryData(videosOptions),
  head: () => ({
    meta: [
      { title: "Vídeos educativos — SUPER PROFS" },
      {
        name: "description",
        content: "Aulas em vídeo organizadas por disciplina e tema, para reforçar o que aprendes.",
      },
      { property: "og:title", content: "Vídeos educativos — SUPER PROFS" },
      {
        property: "og:description",
        content: "Aulas em vídeo organizadas por disciplina e tema.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: VideosPage,
});

function toEmbedUrl(url: string): string | null {
  const match = url.match(/(?:youtu\.be\/|v=|embed\/|shorts\/)([A-Za-z0-9_-]{6,})/);
  return match?.[1] ? `https://www.youtube.com/embed/${match[1]}` : null;
}

function VideosPage() {
  const { data } = useSuspenseQuery(videosOptions);
  const { videos } = data;

  return (
    <div className="container-page py-10 md:py-14">
      <div className="max-w-2xl">
        <h1 className="font-display text-3xl font-bold md:text-4xl">Vídeos educativos</h1>
        <p className="mt-3 text-muted-foreground">
          Aulas em vídeo organizadas por disciplina e tema, para reforçar o que aprendes nos exercícios.
        </p>
      </div>

      {videos.length === 0 ? (
        <Card className="mt-8">
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center text-sm text-muted-foreground">
            <Video className="h-8 w-8 text-brand" />
            Ainda não há vídeos publicados. Volta em breve!
          </CardContent>
        </Card>
      ) : (
        <div className="mt-8 grid gap-6 md:grid-cols-2">
          {videos.map((v) => {
            const embed = toEmbedUrl(v.youtube_url);
            return (
              <Card key={v.id} className="overflow-hidden shadow-card">
                <div className="aspect-video w-full bg-muted">
                  {embed ? (
                    <iframe
                      src={embed}
                      title={v.title}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                      className="h-full w-full"
                      loading="lazy"
                    />
                  ) : (
                    <a
                      href={v.youtube_url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex h-full w-full items-center justify-center text-sm text-muted-foreground underline-offset-4 hover:underline"
                    >
                      Ver vídeo no YouTube
                    </a>
                  )}
                </div>
                <CardHeader>
                  {v.discipline_name && <Badge variant="outline" className="w-fit">{v.discipline_name}</Badge>}
                  <CardTitle className="font-display text-lg">{v.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">{v.description}</CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
