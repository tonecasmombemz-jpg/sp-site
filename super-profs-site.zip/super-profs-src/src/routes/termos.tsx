import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/termos")({
  head: () => ({
    meta: [
      { title: "Termos de utilização — SUPER PROFS" },
      {
        name: "description",
        content: "Termos de utilização da plataforma SUPER PROFS.",
      },
      { property: "og:title", content: "Termos de utilização — SUPER PROFS" },
      { property: "og:description", content: "Termos de utilização da plataforma SUPER PROFS." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TermosPage,
});

function TermosPage() {
  return (
    <div className="container-page max-w-2xl py-10 md:py-14">
      <h1 className="font-display text-3xl font-bold md:text-4xl">Termos de utilização</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Última actualização: Outubro de 2026
      </p>

      <div className="mt-8 flex flex-col gap-6 text-sm leading-relaxed text-muted-foreground">
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">1. O que é a plataforma</h2>
          <p className="mt-2">
            O SUPER PROFS é uma plataforma de preparação para os exames de admissão às universidades,
            com exercícios, simulados, explicações e vídeos educativos. O acesso aos conteúdos
            introdutórios é gratuito; alguns conteúdos e simulados completos exigem um plano pago.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">2. A tua conta</h2>
          <p className="mt-2">
            Para usar a plataforma precisas de uma conta com um email válido e uma palavra-passe. É
            responsabilidade tua manter a palavra-passe segura e não partilhar a tua conta com outras
            pessoas. Os dados que inseres no perfil devem ser verdadeiros.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">3. Uso aceitável</h2>
          <p className="mt-2">
            Os conteúdos (perguntas, explicações, vídeos e simulados) são para uso pessoal de estudo.
            Não é permitido copiar, revender ou redistribuir os conteúdos da plataforma, nem tentar
            aceder a áreas restritas ou interferir no funcionamento do serviço.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">4. Planos e pagamentos</h2>
          <p className="mt-2">
            Os planos pagos são apresentados na página de planos, em meticais (MZN). Quando as
            subscrições estiverem activas, podes cancelar quando quiseres; os detalhes de cobrança
            são apresentados antes de qualquer pagamento.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">5. Resultados de estudo</h2>
          <p className="mt-2">
            As correcções e pontuações mostradas na plataforma servem para acompanhar o teu estudo.
            Não garantem resultados nos exames oficiais das universidades.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">6. Alterações</h2>
          <p className="mt-2">
            Estes termos podem ser actualizados. Se houver mudanças importantes, avisa-se na
            plataforma antes de entrarem em vigor.
          </p>
        </section>
      </div>
    </div>
  );
}
