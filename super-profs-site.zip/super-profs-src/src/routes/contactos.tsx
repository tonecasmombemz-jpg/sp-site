import { createFileRoute, Link } from "@tanstack/react-router";
import { Mail, MapPin, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export const Route = createFileRoute("/contactos")({
  head: () => ({
    meta: [
      { title: "Contactos — SUPER PROFS" },
      {
        name: "description",
        content: "Fala com a equipa do SUPER PROFS: dúvidas sobre a plataforma, planos e conteúdos.",
      },
      { property: "og:title", content: "Contactos — SUPER PROFS" },
      {
        property: "og:description",
        content: "Fala com a equipa do SUPER PROFS.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: ContactosPage,
});

function ContactosPage() {
  return (
    <div className="container-page max-w-2xl py-10 md:py-14">
      <h1 className="font-display text-3xl font-bold md:text-4xl">Contactos</h1>
      <p className="mt-3 text-muted-foreground">
        Estamos aqui para ajudar na tua preparação para o exame de admissão.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <Phone className="h-5 w-5 text-brand" />
            <CardTitle className="text-base">Telefone</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">A definir pela administração</CardContent>
        </Card>
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <Mail className="h-5 w-5 text-brand" />
            <CardTitle className="text-base">Email</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">A definir pela administração</CardContent>
        </Card>
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <MapPin className="h-5 w-5 text-brand" />
            <CardTitle className="text-base">Morada</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">A definir pela administração</CardContent>
        </Card>
      </div>

      <Card className="mt-8 shadow-card">
        <CardHeader>
          <CardTitle className="font-display text-xl">Perguntas frequentes</CardTitle>
        </CardHeader>
        <CardContent className="text-sm leading-relaxed text-muted-foreground">
          <p>
            Muitas dúvidas sobre como usar a plataforma — exercícios, simulados, planos e contas —
            já estão respondidas na página inicial, na secção de perguntas frequentes.
          </p>
          <div className="mt-4 flex flex-wrap gap-3">
            <Button asChild variant="outline">
              <Link to="/">Ver perguntas frequentes</Link>
            </Button>
            <Button asChild variant="ghost">
              <Link to="/planos">Ver planos</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
