import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { ArrowLeft, ChevronRight, ClipboardList, Timer } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DISCIPLINE_ICONS } from "@/components/layout/site-header";
import { getDisciplineBySlug } from "@/lib/study-data";
import { BookOpen } from "lucide-react";

export const Route = createFileRoute("/disciplinas/$slug")({
  loader: async ({ params }) => {
    const data = await getDisciplineBySlug({ data: params.slug });
    if (!data) throw notFound();
    return data;
  },
  head: () => ({
    meta: [
      { title: "Disciplina — SUPER PROFS" },
      {
        name: "description",
        content: "Temas e exercícios desta disciplina, com solução explicada, para o exame de admissão.",
      },
      { property: "og:title", content: "Disciplina — SUPER PROFS" },
      {
        property: "og:description",
        content: "Temas e exercícios desta disciplina para o exame de admissão.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DisciplinaPage,
});

function DisciplinaPage() {
  const { discipline, themes, exams } = Route.useLoaderData();
  const Icon = DISCIPLINE_ICONS[discipline.icon] ?? BookOpen;

  return (
    <div className="container-page py-10 md:py-14">
      <Link
        to="/disciplinas"
        className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" /> Todas as disciplinas
      </Link>

      <div className="mt-4 flex items-start gap-4">
        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-navy text-primary-foreground">
          <Icon className="h-7 w-7" />
        </div>
        <div>
          <h1 className="font-display text-3xl font-bold md:text-4xl">{discipline.name}</h1>
          <p className="mt-2 max-w-2xl text-muted-foreground">{discipline.description}</p>
        </div>
      </div>

      <section className="mt-10">
        <h2 className="font-display text-2xl font-bold">Temas</h2>
        {themes.length === 0 ? (
          <Card className="mt-4">
            <CardContent className="py-10 text-center text-sm text-muted-foreground">
              Ainda não há temas publicados nesta disciplina.
            </CardContent>
          </Card>
        ) : (
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            {themes.map((t) => (
              <Card key={t.id} className="shadow-card">
                <CardHeader>
                  <CardTitle className="font-display text-lg">{t.name}</CardTitle>
                  {t.description && (
                    <p className="text-sm text-muted-foreground">{t.description}</p>
                  )}
                </CardHeader>
                <CardContent className="flex items-center justify-between gap-3">
                  <p className="text-xs text-muted-foreground">
                    {t.question_count === 0
                      ? "Sem exercícios ainda"
                      : `${t.question_count} ${t.question_count === 1 ? "exercício" : "exercícios"}${t.premium_count > 0 ? ` · ${t.premium_count} premium` : ""}`}
                  </p>
                  {t.question_count > 0 && (
                    <Button asChild size="sm" className="gap-1.5">
                      <Link to="/praticar/$themeId" params={{ themeId: t.id }}>
                        Praticar <ChevronRight className="h-4 w-4" />
                      </Link>
                    </Button>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      {exams.length > 0 && (
        <section className="mt-10">
          <h2 className="font-display text-2xl font-bold">Simulados desta disciplina</h2>
          <div className="mt-4 grid gap-4 md:grid-cols-3">
            {exams.map((e) => (
              <Link key={e.id} to="/simulados/$examId" params={{ examId: e.id }}>
                <Card className="h-full shadow-card transition-shadow hover:shadow-card-hover">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      {e.is_demo && <Badge variant="secondary">Demonstração</Badge>}
                      {e.is_premium && <Badge className="bg-brand text-navy">Premium</Badge>}
                    </div>
                    <CardTitle className="text-base leading-snug">{e.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-muted-foreground">
                    {e.description}
                    {e.duration_minutes ? (
                      <p className="mt-3 flex items-center gap-1.5 text-xs">
                        <Timer className="h-3.5 w-3.5 text-brand" /> {e.duration_minutes} minutos
                      </p>
                    ) : null}
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </section>
      )}

      <p className="mt-10 flex items-center gap-2 text-sm text-muted-foreground">
        <ClipboardList className="h-4 w-4 text-brand" />
        Cada exercício tem solução explicada — responde e aprende com os teus erros.
      </p>
    </div>
  );
}
