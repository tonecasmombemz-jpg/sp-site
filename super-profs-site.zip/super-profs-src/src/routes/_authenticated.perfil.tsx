import { createFileRoute } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useState, type FormEvent } from "react";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import { getMyDashboard, updateMyProfile } from "@/lib/study-data";

const profileOptions = queryOptions({
  queryKey: ["perfil"],
  queryFn: () => getMyDashboard(),
});

export const Route = createFileRoute("/_authenticated/perfil")({
  loader: ({ context }) => context.queryClient.ensureQueryData(profileOptions),
  head: () => ({
    meta: [
      { title: "Perfil — SUPER PROFS" },
      {
        name: "description",
        content: "Actualiza os teus dados de estudante e a tua palavra-passe.",
      },
      { property: "og:title", content: "Perfil — SUPER PROFS" },
      {
        property: "og:description",
        content: "Actualiza os teus dados de estudante e a tua palavra-passe.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PerfilPage,
});

function PerfilPage() {
  const { data } = useSuspenseQuery(profileOptions);
  const profile = data.profile;
  const user = useSession().user;

  const updateFn = useServerFn(updateMyProfile);

  const [fullName, setFullName] = useState(profile?.full_name ?? "");
  const [school, setSchool] = useState(profile?.school ?? "");
  const [targetExam, setTargetExam] = useState(profile?.target_exam ?? "");
  const [saving, setSaving] = useState(false);

  const [newPassword, setNewPassword] = useState("");
  const [changingPassword, setChangingPassword] = useState(false);

  const handleSave = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    setSaving(true);
    try {
      const r = await updateFn({
        data: {
          fullName: fullName.trim(),
          school: school.trim() || null,
          targetExam: targetExam.trim() || null,
        },
      });
      if (!r.ok) {
        toast.error("Não foi possível guardar as alterações.");
        return;
      }
      if (user) {
        await supabase.auth.updateUser({ data: { full_name: fullName.trim() } });
      }
      toast.success("Perfil actualizado!");
    } catch {
      toast.error("Não foi possível guardar as alterações.");
    } finally {
      setSaving(false);
    }
  };

  const handleChangePassword = async (e: FormEvent) => {
    e.preventDefault();
    if (changingPassword) return;
    if (newPassword.length < 6) {
      toast.error("A nova palavra-passe deve ter pelo menos 6 caracteres.");
      return;
    }
    setChangingPassword(true);
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    setChangingPassword(false);
    if (error) {
      toast.error("Não foi possível alterar a palavra-passe.");
      return;
    }
    setNewPassword("");
    toast.success("Palavra-passe alterada!");
  };

  return (
    <div className="container-page max-w-2xl py-10 md:py-14">
      <h1 className="font-display text-3xl font-bold md:text-4xl">Perfil</h1>
      <p className="mt-2 text-muted-foreground">
        Mantém os teus dados actualizados para uma melhor experiência de estudo.
      </p>

      <Card className="mt-8 shadow-card">
        <CardHeader>
          <CardTitle className="font-display text-xl">Dados do estudante</CardTitle>
          <CardDescription>{user?.email}</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSave} className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <Label htmlFor="fullName">Nome completo</Label>
              <Input
                id="fullName"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="school">Escola (opcional)</Label>
              <Input
                id="school"
                value={school}
                onChange={(e) => setSchool(e.target.value)}
                placeholder="Nome da tua escola"
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="targetExam">Universidade ou curso alvo (opcional)</Label>
              <Input
                id="targetExam"
                value={targetExam}
                onChange={(e) => setTargetExam(e.target.value)}
                placeholder="Ex.: UEM — Engenharia"
              />
            </div>
            <Button type="submit" disabled={saving} className="mt-1 w-fit">
              {saving ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Guardar alterações
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card className="mt-6 shadow-card">
        <CardHeader>
          <CardTitle className="font-display text-xl">Palavra-passe</CardTitle>
          <CardDescription>Usa pelo menos 6 caracteres.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleChangePassword} className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <Label htmlFor="newPassword">Nova palavra-passe</Label>
              <Input
                id="newPassword"
                type="password"
                minLength={6}
                required
                autoComplete="new-password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="••••••••"
              />
            </div>
            <Button type="submit" variant="outline" disabled={changingPassword} className="w-fit">
              {changingPassword ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
              Alterar palavra-passe
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
