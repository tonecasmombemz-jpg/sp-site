import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/disciplinas")({
  component: DisciplinasLayout,
});

function DisciplinasLayout() {
  return <Outlet />;
}
