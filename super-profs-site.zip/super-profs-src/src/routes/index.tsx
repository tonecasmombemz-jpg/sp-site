import { createFileRoute, Link } from "@tanstack/react-router";
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DISCIPLINE_ICONS } from "@/components/layout/site-header";
import { getLandingData, type ExamItem } from "@/lib/public-data";
import { BookOpen, BrainCircuit, CheckCircle2, ClipboardList, ListChecks, Timer, Video, Sparkles } from "lucide-react";
import heroUrl from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  loader: () => getLandingData(),
  head: () => ({
    meta: [
      { title: "SUPER PROFS — A tua aprovação começa aqui!" },
      {
        name: "description",
        content:
          "Plataforma moçambicana de preparação para os exames de admissão às universidades: exercícios, simulados, explicações e vídeos em português.",
      },
      { property: "og:title", content: "SUPER PROFS — A tua aprovação começa aqui!" },
      {
        property: "og:description",
        content:
          "Exercícios, testes, explicações e conteúdos organizados para os exames de admissão em Moçambique.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: IndexPage,
});

const FAQ = [
  {
    q: "O que é o SUPER PROFS?",
    a: "É uma plataforma moçambicana de preparação para os exames de admissão às universidades, com exercícios, simulados com correção automática, explicações e vídeos educativos.",
  },
  {
    q: "Que disciplinas posso estudar?",
    a: "Começamos com Matemática, Física, Química, Português, Biologia e Inglês. O administrador da plataforma pode adicionar outras disciplinas.",
  },
  {
    q: "Os exercícios têm explicação da solução?",
    a: "Sim. Cada pergunta apresenta a explicação da resposta correcta depois de responderes, para ajudares a compreender os teus erros.",
  },
  {
    q: "Preciso de pagar para começar?",
    a: "Não. Podes criar uma conta gratuita e começar pelos conteúdos introdutórios. O plano premium oferece simulados completos e recursos adicionais.",
  },
  {
    q: "Posso estudar no telemóvel?",
    a: "Sim. O site funciona em computadores, tablets e telemóveis, com um menu adaptado a ecrãs pequenos.",
  },
];

function IndexPage() {
  const { disciplines, exams } = Route.useLoaderData();

  return (
    <div className="flex flex-col">
      {/* Hero */}
      <section className="hero-gradient text-primary-foreground">
        <div className="container-page grid items-center gap-10 py-16 md:grid-cols-2 md:py-24">
          <div className="fade-up">
            <Badge variant="outline" className="border-brand/50 bg-white/5 text-brand-soft">
              <Sparkles className="mr-1.5 h-3.5 w-3.5" /> Preparação para exames de admissão
            </Badge>
            <h1 className="mt-4 font-display text-4xl font-bold leading-tight md:text-5xl">
              A tua aprovação <span className="brand-gradient-text">começa aqui!</span>
            </h1>
            <p className="mt-4 max-w-xl text-base leading-relaxed text-primary-foreground/85">
              Prepara-te para os exames de admissão com exercícios, testes, explicações e
              conteúdos organizados para alcançares os teus objectivos académicos.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button asChild size="lg" className="bg-brand text-navy hover:bg-brand/90">
                <Link to="/registar">Criar conta grátis</Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white/30 bg-transparent text-primary-foreground hover:bg-white/10 hover:text-primary-foreground"
              >
                <Link to="/disciplinas">Ver disciplinas</Link>
              </Button>
            </div>
          </div>
          <div className="fade-up">
            <img
              src={heroUrl}
              alt="Estudantes moçambicanos a estudar em conjunto"
              className="w-full rounded-2xl object-cover shadow-card-hover"
              width={1440}
              height={720}
            />
          </div>
        </div>
      </section>

      {/* Benefícios */}
      <section className="section-pad bg-background">
        <div className="container-page">
          <h2 className="text-center font-display text-3xl font-bold">Porque estudar connosco</h2>
          <p className="mx-auto mt-3 max-w-2xl text-center text-muted-foreground">
            Ferramentas pensadas para o exame de admissão, do exercício diário ao simulado completo.
          </p>
          <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {[
              { icon: ListChecks, t: "Exercícios por tema", d: "Resolve exercícios por disciplina e tema, com dificuldade progressiva e solução explicada." },
              { icon: ClipboardList, t: "Simulados completos", d: "Testes com temporizador opcional, navegação entre perguntas e correção automática." },
              { icon: BrainCircuit, t: "Explicações com IA", d: "Pede uma explicação passo a passo, em português simples, sempre que ficares com dúvidas." },
              { icon: Video, t: "Vídeos educativos", d: "Aulas em vídeo organizadas por disciplina e tema, para reforçar o que aprendes." },
            ].map((b) => (
              <Card key={b.t} className="border-border/70 shadow-card transition-shadow hover:shadow-card-hover">
                <CardHeader>
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-secondary">
                    <b.icon className="h-5 w-5 text-navy" />
                  </div>
                  <CardTitle className="text-base">{b.t}</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">{b.d}</CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Disciplinas */}
      <section className="section-pad bg-secondary/40">
        <div className="container-page">
          <h2 className="font-display text-3xl font-bold">Disciplinas disponíveis</h2>
          <p className="mt-3 text-muted-foreground">Conteúdos organizados por temas, capítulos e níveis de dificuldade.</p>
          <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {disciplines.map((d) => {
              const Icon = DISCIPLINE_ICONS[d.icon] ?? BookOpen;
              return (
                <Link key={d.id} to="/disciplinas/$slug" params={{ slug: d.slug }}>
                  <Card className="h-full shadow-card transition-shadow hover:shadow-card-hover">
                    <CardContent className="flex items-start gap-4 pt-6">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-navy text-primary-foreground">
                        <Icon className="h-6 w-6" />
                      </div>
                      <div>
                        <h3 className="font-display text-lg font-semibold">{d.name}</h3>
                        <p className="mt-1 text-sm text-muted-foreground">{d.description}</p>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Simulados */}
      <section className="section-pad bg-background">
        <div className="container-page">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <h2 className="font-display text-3xl font-bold">Exames e preparação</h2>
              <p className="mt-3 max-w-2xl text-muted-foreground">
                Simulados com perguntas de escolha múltipla, temporizador opcional e correção automática.
              </p>
            </div>
            <Button asChild variant="outline">
              <Link to="/simulados">Ver todos os simulados</Link>
            </Button>
          </div>
          {exams.length === 0 ? (
            <Card className="mt-8">
              <CardContent className="py-10 text-center text-sm text-muted-foreground">
                Ainda não existem simulados publicados. O administrador pode publicá-los no painel de gestão.
              </CardContent>
            </Card>
          ) : (
            <div className="mt-8 grid gap-4 md:grid-cols-3">
              {exams.map((e: ExamItem) => (
                <Card key={e.id} className="shadow-card">
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      {e.is_demo && <Badge variant="secondary">Demonstração</Badge>}
                      {e.is_premium && <Badge className="bg-brand text-navy">Premium</Badge>}
                    </div>
                    <CardTitle className="text-base leading-snug">{e.title}</CardTitle>
                  </CardHeader>
                  <CardContent className="text-sm text-muted-foreground">
                    {e.description}
                    {e.duration_minutes ? (
                      <p className="mt-3 flex items-center gap-1.5 text-xs">
                        <Timer className="h-3.5 w-3.5 text-brand" /> {e.duration_minutes} minutos
                      </p>
                    ) : null}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Estatísticas honestas (sem números inventados) */}
      <section className="border-y border-border bg-card">
        <div className="container-page grid gap-6 py-10 text-center sm:grid-cols-3">
          <div>
            <p className="font-display text-3xl font-bold text-navy">{disciplines.length}</p>
            <p className="mt-1 text-sm text-muted-foreground">Disciplinas essenciais para o exame</p>
          </div>
          <div>
            <p className="font-display text-3xl font-bold text-navy">100%</p>
            <p className="mt-1 text-sm text-muted-foreground">Em português, com explicações passo a passo</p>
          </div>
          <div>
            <p className="font-display text-3xl font-bold text-navy">Automática</p>
            <p className="mt-1 text-sm text-muted-foreground">Correção dos testes, com solução certa e errada</p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="section-pad bg-background">
        <div className="container-page max-w-3xl">
          <h2 className="text-center font-display text-3xl font-bold">Perguntas frequentes</h2>
          <Accordion type="single" collapsible className="mt-8">
            {FAQ.map((f, i) => (
              <AccordionItem key={i} value={`item-${i}`}>
                <AccordionTrigger className="text-left text-base">{f.q}</AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground">{f.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </section>

      {/* CTA final */}
      <section className="section-pad hero-gradient text-primary-foreground">
        <div className="container-page text-center">
          <h2 className="font-display text-3xl font-bold md:text-4xl">
            Começa hoje a tua preparação
          </h2>
          <p className="mx-auto mt-3 max-w-xl text-primary-foreground/85">
            Cria a tua conta gratuita e acompanha o teu progresso, resultado a resultado.
          </p>
          <div className="mt-7 flex flex-wrap justify-center gap-3">
            <Button asChild size="lg" className="bg-brand text-navy hover:bg-brand/90">
              <Link to="/registar">Criar conta grátis</Link>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-white/30 bg-transparent text-primary-foreground hover:bg-white/10 hover:text-primary-foreground"
            >
              <Link to="/planos">Ver planos</Link>
            </Button>
          </div>
          <p className="mt-6 flex items-center justify-center gap-1.5 text-xs text-primary-foreground/70">
            <CheckCircle2 className="h-3.5 w-3.5 text-brand" /> Registo gratuito · Cancela quando quiseres
          </p>
        </div>
      </section>
    </div>
  );
}
