import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/simulados")({
  component: SimuladosLayout,
});

function SimuladosLayout() {
  return <Outlet />;
}
