import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ClipboardList, Timer } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { getExamsList } from "@/lib/study-data";

const examsOptions = queryOptions({
  queryKey: ["simulados"],
  queryFn: () => getExamsList(),
});

export const Route = createFileRoute("/simulados/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(examsOptions),
  head: () => ({
    meta: [
      { title: "Simulados — SUPER PROFS" },
      {
        name: "description",
        content:
          "Simulados completos de preparação para o exame de admissão, com temporizador opcional e correção automática.",
      },
      { property: "og:title", content: "Simulados — SUPER PROFS" },
      {
        property: "og:description",
        content: "Simulados com perguntas de escolha múltipla, temporizador e correção automática.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SimuladosPage,
});

function SimuladosPage() {
  const { data } = useSuspenseQuery(examsOptions);
  const { exams } = data;

  return (
    <div className="container-page py-10 md:py-14">
      <div className="max-w-2xl">
        <h1 className="font-display text-3xl font-bold md:text-4xl">Simulados</h1>
        <p className="mt-3 text-muted-foreground">
          Testes completos com perguntas de escolha múltipla, temporizador opcional e correção
          automática no fim.
        </p>
      </div>

      {exams.length === 0 ? (
        <Card className="mt-8">
          <CardContent className="flex flex-col items-center gap-3 py-12 text-center text-sm text-muted-foreground">
            <ClipboardList className="h-8 w-8 text-brand" />
            Ainda não existem simulados publicados. O administrador pode publicá-los no painel de gestão.
          </CardContent>
        </Card>
      ) : (
        <div className="mt-8 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {exams.map((e) => (
            <Link key={e.id} to="/simulados/$examId" params={{ examId: e.id }} className="group">
              <Card className="h-full shadow-card transition-shadow hover:shadow-card-hover">
                <CardHeader>
                  <div className="flex flex-wrap items-center gap-2">
                    {e.is_demo && <Badge variant="secondary">Demonstração</Badge>}
                    {e.is_premium && <Badge className="bg-brand text-navy">Premium</Badge>}
                    {e.discipline_name && <Badge variant="outline">{e.discipline_name}</Badge>}
                  </div>
                  <CardTitle className="font-display text-lg leading-snug">{e.title}</CardTitle>
                </CardHeader>
                <CardContent className="text-sm text-muted-foreground">
                  {e.description}
                  <div className="mt-3 flex items-center gap-4 text-xs">
                    {e.duration_minutes ? (
                      <span className="flex items-center gap-1.5">
                        <Timer className="h-3.5 w-3.5 text-brand" /> {e.duration_minutes} minutos
                      </span>
                    ) : null}
                    <span className="text-primary font-medium group-hover:underline">Resolver →</span>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
