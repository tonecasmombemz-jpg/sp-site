import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { BookOpen } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { DISCIPLINE_ICONS } from "@/components/layout/site-header";
import { getDisciplinesWithThemes } from "@/lib/public-data";

const disciplinesOptions = queryOptions({
  queryKey: ["disciplinas"],
  queryFn: () => getDisciplinesWithThemes(),
});

export const Route = createFileRoute("/disciplinas/")({
  loader: ({ context }) => context.queryClient.ensureQueryData(disciplinesOptions),
  head: () => ({
    meta: [
      { title: "Disciplinas — SUPER PROFS" },
      {
        name: "description",
        content:
          "Matemática, Física, Química, Português, Biologia e Inglês: exercícios organizados por tema para o exame de admissão.",
      },
      { property: "og:title", content: "Disciplinas — SUPER PROFS" },
      {
        property: "og:description",
        content: "Exercícios organizados por disciplina e tema para o exame de admissão.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: DisciplinasPage,
});

function DisciplinasPage() {
  const { data } = useSuspenseQuery(disciplinesOptions);
  const { disciplines } = data;

  return (
    <div className="container-page py-10 md:py-14">
      <div className="max-w-2xl">
        <h1 className="font-display text-3xl font-bold md:text-4xl">Disciplinas</h1>
        <p className="mt-3 text-muted-foreground">
          Escolhe uma disciplina para ver os temas e começar a resolver exercícios com solução explicada.
        </p>
      </div>

      {disciplines.length === 0 ? (
        <Card className="mt-8">
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            Ainda não existem disciplinas publicadas.
          </CardContent>
        </Card>
      ) : (
        <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {disciplines.map((d) => {
            const Icon = DISCIPLINE_ICONS[d.icon] ?? BookOpen;
            return (
              <Link key={d.id} to="/disciplinas/$slug" params={{ slug: d.slug }} className="group">
                <Card className="h-full shadow-card transition-shadow hover:shadow-card-hover">
                  <CardHeader>
                    <div className="flex items-start gap-3">
                      <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-navy text-primary-foreground">
                        <Icon className="h-5 w-5" />
                      </div>
                      <div>
                        <CardTitle className="font-display text-lg">{d.name}</CardTitle>
                        {d.themes.length > 0 && (
                          <p className="mt-0.5 text-xs text-muted-foreground">
                            {d.themes.length} {d.themes.length === 1 ? "tema" : "temas"}
                          </p>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground">{d.description}</p>
                    {d.themes.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-1.5">
                        {d.themes.slice(0, 4).map((t) => (
                          <Badge key={t.id} variant="secondary" className="text-xs font-normal">
                            {t.name}
                          </Badge>
                        ))}
                        {d.themes.length > 4 && (
                          <Badge variant="secondary" className="text-xs font-normal">
                            +{d.themes.length - 4}
                          </Badge>
                        )}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
