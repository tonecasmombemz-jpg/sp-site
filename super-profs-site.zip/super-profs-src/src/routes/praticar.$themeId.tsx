import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useState } from "react";
import { ArrowLeft, ArrowRight, CheckCircle2, Loader2, RotateCcw, Sparkles, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useSession } from "@/hooks/use-session";
import {
  checkExerciseAnswer,
  explainQuestion,
  getThemePractice,
  getThemePracticePremium,
  saveExerciseAnswer,
  type AnswerCheck,
} from "@/lib/study-data";

export const Route = createFileRoute("/praticar/$themeId")({
  loader: async ({ params }) => {
    const data = await getThemePractice({ data: { themeId: params.themeId } });
    if (!data) throw notFound();
    return data;
  },
  head: () => ({
    meta: [
      { title: "Praticar — SUPER PROFS" },
      {
        name: "description",
        content: "Resolve exercícios de escolha múltipla com solução explicada e explicações passo a passo.",
      },
      { property: "og:title", content: "Praticar — SUPER PROFS" },
      {
        property: "og:description",
        content: "Exercícios de escolha múltipla com solução explicada.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PraticarPage,
});

function PraticarPage() {
  const initial = Route.useLoaderData();
  const themeId = Route.useParams().themeId;
  const { user } = useSession();

  const checkFn = useServerFn(checkExerciseAnswer);
  const saveFn = useServerFn(saveExerciseAnswer);
  const premiumFn = useServerFn(getThemePracticePremium);
  const explainFn = useServerFn(explainQuestion);

  const [questions, setQuestions] = useState(initial.questions);
  const [index, setIndex] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState<AnswerCheck | null>(null);
  const [stats, setStats] = useState({ answered: 0, correct: 0 });
  const [finished, setFinished] = useState(false);
  const [aiText, setAiText] = useState<string | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  // Estudantes premium recebem também as perguntas premium do tema.
  useEffect(() => {
    if (!user) return;
    let cancelled = false;
    premiumFn({ data: { themeId } })
      .then((r) => {
        if (!cancelled && r.allowed && r.questions.length >= initial.questions.length) {
          setQuestions(r.questions);
        }
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, themeId]);

  const question = questions[index];

  const handleAnswer = async (alternativeId: string) => {
    if (result || checking || !question) return;
    setSelected(alternativeId);
    setChecking(true);
    try {
      const check = await checkFn({ data: { questionId: question.id, alternativeId } });
      setResult(check);
      setStats((s) => ({
        answered: s.answered + 1,
        correct: s.correct + (check.isCorrect ? 1 : 0),
      }));
      if (user) {
        saveFn({ data: { questionId: question.id, alternativeId } }).catch(() => {});
      }
    } catch {
      toast.error("Não foi possível verificar a resposta. Tenta novamente.");
      setSelected(null);
    } finally {
      setChecking(false);
    }
  };

  const handleNext = () => {
    if (index + 1 >= questions.length) {
      setFinished(true);
      return;
    }
    setIndex(index + 1);
    setSelected(null);
    setResult(null);
    setAiText(null);
  };

  const handleRestart = () => {
    setIndex(0);
    setSelected(null);
    setResult(null);
    setAiText(null);
    setStats({ answered: 0, correct: 0 });
    setFinished(false);
  };

  const handleExplain = async () => {
    if (!user) {
      toast.error("Entra na tua conta para usares as explicações com IA.");
      return;
    }
    if (!question || aiLoading) return;
    setAiLoading(true);
    try {
      const selectedContent =
        question.alternatives.find((a) => a.id === selected)?.content ?? null;
      const response = await explainFn({
        data: {
          statement: question.statement,
          alternatives: question.alternatives.map((a) => a.content),
          selected: selectedContent,
          isCorrect: result?.isCorrect ?? false,
          discipline: initial.discipline?.name ?? "",
          theme: initial.theme.name,
        },
      });
      if ("error" in response && response.error) {
        toast.error(response.error);
      } else if ("explanation" in response && response.explanation) {
        setAiText(response.explanation);
      }
    } catch {
      toast.error("Não foi possível obter a explicação com IA.");
    } finally {
      setAiLoading(false);
    }
  };

  if (questions.length === 0) {
    return (
      <div className="container-page py-16">
        <Card className="mx-auto max-w-lg text-center">
          <CardHeader>
            <CardTitle className="font-display text-xl">{initial.theme.name}</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground">
            Ainda não há exercícios publicados neste tema. Volta em breve!
            <div className="mt-4">
              <Button asChild variant="outline">
                {initial.discipline ? (
                  <Link to="/disciplinas/$slug" params={{ slug: initial.discipline.slug }}>
                    Voltar à disciplina
                  </Link>
                ) : (
                  <Link to="/disciplinas">Voltar às disciplinas</Link>
                )}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (finished) {
    const percent = stats.answered ? Math.round((stats.correct / stats.answered) * 100) : 0;
    return (
      <div className="container-page py-16">
        <Card className="mx-auto max-w-lg text-center shadow-card">
          <CardHeader>
            <CheckCircle2 className="mx-auto h-10 w-10 text-brand" />
            <CardTitle className="font-display text-2xl">Sessão concluída!</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-display text-4xl font-bold text-navy">{percent}%</p>
            <p className="mt-2 text-sm text-muted-foreground">
              Acertaste {stats.correct} de {stats.answered} respostas em {initial.theme.name}.
            </p>
            <div className="mt-6 flex flex-wrap justify-center gap-3">
              <Button onClick={handleRestart} variant="outline" className="gap-2">
                <RotateCcw className="h-4 w-4" /> Repetir
              </Button>
              {initial.discipline && (
                <Button asChild>
                  <Link to="/disciplinas/$slug" params={{ slug: initial.discipline.slug }}>
                    Outros temas
                  </Link>
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!question) return null;

  const selectedContent = question.alternatives.find((a) => a.id === selected)?.content ?? null;
  const correctContent =
    question.alternatives.find((a) => a.id === result?.correctAlternativeId)?.content ?? null;

  return (
    <div className="container-page max-w-3xl py-8 md:py-12">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          {initial.discipline && (
            <Link
              to="/disciplinas/$slug"
              params={{ slug: initial.discipline.slug }}
              className="inline-flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground"
            >
              <ArrowLeft className="h-4 w-4" /> {initial.discipline.name}
            </Link>
          )}
          <h1 className="font-display text-2xl font-bold">{initial.theme.name}</h1>
        </div>
        <Badge variant="secondary">
          Pergunta {index + 1} de {questions.length}
        </Badge>
      </div>

      <Progress value={((index + (result ? 1 : 0)) / questions.length) * 100} className="mt-4 h-2" />

      <Card className="mt-6 shadow-card">
        <CardHeader>
          <div className="flex items-center justify-between gap-2">
            <Badge variant="outline" className="capitalize">
              {question.difficulty}
            </Badge>
            {question.is_premium && <Badge className="bg-brand text-navy">Premium</Badge>}
          </div>
          <CardTitle className="text-lg leading-relaxed">{question.statement}</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col gap-2.5">
          {question.alternatives.map((alt) => {
            const isSelected = selected === alt.id;
            const isCorrectReveal = result?.correctAlternativeId === alt.id;
            const isWrongPick = isSelected && result && !result.isCorrect;
            return (
              <button
                key={alt.id}
                type="button"
                disabled={!!result || checking}
                onClick={() => handleAnswer(alt.id)}
                className={`rounded-lg border px-4 py-3 text-left text-sm transition-colors ${
                  isCorrectReveal
                    ? "border-primary bg-primary/10 font-medium text-primary"
                    : isWrongPick
                      ? "border-destructive bg-destructive/10 text-destructive"
                      : "border-border bg-background hover:bg-secondary"
                }`}
              >
                <span className="flex items-start justify-between gap-3">
                  <span>{alt.content}</span>
                  {isCorrectReveal && <CheckCircle2 className="h-4 w-4 shrink-0" />}
                  {isWrongPick && <XCircle className="h-4 w-4 shrink-0" />}
                </span>
              </button>
            );
          })}

          {checking && (
            <p className="flex items-center gap-2 pt-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" /> A verificar…
            </p>
          )}

          {result && (
            <div className="mt-3 flex flex-col gap-3 rounded-lg border border-border bg-secondary/40 p-4">
              <p className={`text-sm font-medium ${result.isCorrect ? "text-primary" : "text-destructive"}`}>
                {result.isCorrect
                  ? "Correcto! Boa resposta."
                  : selectedContent
                    ? `Resposta incorrecta. A resposta certa é: ${correctContent}`
                    : "A resposta certa é: " + correctContent}
              </p>
              {result.explanation && (
                <p className="text-sm leading-relaxed text-muted-foreground">{result.explanation}</p>
              )}
              <div>
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  onClick={handleExplain}
                  disabled={aiLoading}
                  className="gap-2"
                >
                  {aiLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <Sparkles className="h-4 w-4 text-brand" />
                  )}
                  Explicar melhor com IA
                </Button>
              </div>
              {aiText && (
                <div className="rounded-md border border-brand/40 bg-background p-4 text-sm leading-relaxed whitespace-pre-line">
                  {aiText}
                </div>
              )}
              <Button onClick={handleNext} className="mt-1 gap-2">
                {index + 1 >= questions.length ? "Ver resultado" : "Próxima pergunta"}
                <ArrowRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
