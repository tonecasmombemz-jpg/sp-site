import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { BookOpenCheck, ClipboardList, Sparkles, Target } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardHeader, CardTitle,
} from "@/components/ui/card";
import { getMyDashboard } from "@/lib/study-data";

const dashboardOptions = queryOptions({
  queryKey: ["painel"],
  queryFn: () => getMyDashboard(),
});

export const Route = createFileRoute("/_authenticated/painel")({
  loader: ({ context }) => context.queryClient.ensureQueryData(dashboardOptions),
  head: () => ({
    meta: [
      { title: "O meu painel — SUPER PROFS" },
      {
        name: "description",
        content: "Acompanha o teu progresso: exercícios resolvidos, taxa de acerto e resultados dos simulados.",
      },
      { property: "og:title", content: "O meu painel — SUPER PROFS" },
      {
        property: "og:description",
        content: "Acompanha o teu progresso, resultado a resultado.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PainelPage,
});

function PainelPage() {
  const { data } = useSuspenseQuery(dashboardOptions);
  const { profile, exercise, attempts, subscription } = data;

  const accuracy = exercise.total ? Math.round((exercise.correct / exercise.total) * 100) : null;
  const isPremium = profile?.plan === "premium" || subscription?.status === "active";
  const displayName = profile?.full_name || "Estudante";

  return (
    <div className="container-page py-10 md:py-14">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="font-display text-3xl font-bold md:text-4xl">Olá, {displayName}!</h1>
          <p className="mt-2 text-muted-foreground">
            Aqui está o teu progresso na preparação para o exame de admissão.
          </p>
        </div>
        <Badge variant={isPremium ? "default" : "secondary"} className={isPremium ? "bg-brand text-navy" : ""}>
          {isPremium ? "Plano premium" : "Plano grátis"}
        </Badge>
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <BookOpenCheck className="h-4 w-4 text-brand" /> Exercícios resolvidos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-display text-3xl font-bold text-navy">{exercise.total}</p>
          </CardContent>
        </Card>
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <Target className="h-4 w-4 text-brand" /> Taxa de acerto
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-display text-3xl font-bold text-navy">
              {accuracy === null ? "—" : `${accuracy}%`}
            </p>
          </CardContent>
        </Card>
        <Card className="shadow-card">
          <CardHeader className="pb-2">
            <CardTitle className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
              <ClipboardList className="h-4 w-4 text-brand" /> Simulados feitos
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="font-display text-3xl font-bold text-navy">{attempts.length}</p>
          </CardContent>
        </Card>
      </div>

      {!isPremium && (
        <Card className="mt-6 border-brand/50 shadow-card">
          <CardContent className="flex flex-wrap items-center justify-between gap-4 py-5">
            <div className="flex items-start gap-3">
              <Sparkles className="mt-0.5 h-5 w-5 text-brand" />
              <div>
                <p className="font-medium">Desbloqueia o plano premium</p>
                <p className="text-sm text-muted-foreground">
                  Simulados completos, perguntas premium e mais recursos para a tua aprovação.
                </p>
              </div>
            </div>
            <Button className="bg-brand text-navy hover:bg-brand/90">
              <Link to="/planos">Ver planos</Link>
            </Button>
          </CardContent>
        </Card>
      )}

      <section className="mt-10">
        <h2 className="font-display text-2xl font-bold">Últimos simulados</h2>
        {attempts.length === 0 ? (
          <Card className="mt-4">
            <CardContent className="flex flex-col items-center gap-3 py-10 text-center text-sm text-muted-foreground">
              Ainda não fizeste nenhum simulado.
              <Button asChild size="sm">
                <Link to="/simulados">Ver simulados</Link>
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="mt-4 flex flex-col gap-3">
            {attempts.map((a) => (
              <Card key={a.id} className="shadow-card">
                <CardContent className="flex flex-wrap items-center justify-between gap-3 py-4">
                  <div>
                    <p className="font-medium">{a.exam_title ?? "Simulado"}</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(a.started_at).toLocaleDateString("pt-PT", {
                        day: "numeric",
                        month: "long",
                        year: "numeric",
                      })}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="font-display text-xl font-bold text-navy">{a.score_percent}%</p>
                    <p className="text-xs text-muted-foreground">
                      {a.correct_count}/{a.total_questions} certas
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
