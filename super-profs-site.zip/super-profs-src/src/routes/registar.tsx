import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Loader2, MailCheck, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/registar")({
  head: () => ({
    meta: [
      { title: "Criar conta grátis — SUPER PROFS" },
      {
        name: "description",
        content: "Cria a tua conta gratuita e começa a preparar-te para os exames de admissão às universidades.",
      },
      { property: "og:title", content: "Criar conta grátis — SUPER PROFS" },
      {
        property: "og:description",
        content: "Cria a tua conta gratuita e começa a preparar-te para os exames de admissão.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: RegistarPage,
});

function RegistarPage() {
  const navigate = useNavigate();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [awaitingConfirmation, setAwaitingConfirmation] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (busy) return;
    if (password.length < 6) {
      toast.error("A palavra-passe deve ter pelo menos 6 caracteres.");
      return;
    }
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({
      email: email.trim(),
      password,
      options: { data: { full_name: fullName.trim() } },
    });
    setBusy(false);
    if (error) {
      if (error.message.toLowerCase().includes("already") || error.status === 422) {
        toast.error("Já existe uma conta com este email. Tenta entrar.");
      } else {
        toast.error("Não foi possível criar a conta. Verifica os dados e tenta novamente.");
      }
      return;
    }
    if (data.session) {
      toast.success("Conta criada! Bem-vindo ao SUPER PROFS.");
      await navigate({ to: "/painel", replace: true });
      return;
    }
    setAwaitingConfirmation(email.trim());
  };

  if (awaitingConfirmation) {
    return (
      <div className="container-page flex flex-1 items-center justify-center py-16">
        <Card className="w-full max-w-md text-center shadow-card">
          <CardHeader>
            <MailCheck className="mx-auto h-10 w-10 text-brand" />
            <CardTitle className="font-display text-2xl">Confirma o teu email</CardTitle>
            <CardDescription>
              Enviámos um link de confirmação para <span className="font-medium text-foreground">{awaitingConfirmation}</span>.
              Depois de confirmares, podes entrar na tua conta.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button asChild variant="outline" className="w-full">
              <Link to="/entrar">Ir para a página de entrada</Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container-page flex flex-1 items-center justify-center py-16">
      <Card className="w-full max-w-md shadow-card">
        <CardHeader className="text-center">
          <CardTitle className="font-display text-2xl">Criar conta grátis</CardTitle>
          <CardDescription>Começa hoje a tua preparação para o exame de admissão.</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <div className="flex flex-col gap-2">
              <Label htmlFor="fullName">Nome completo</Label>
              <Input
                id="fullName"
                required
                autoComplete="name"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder="O teu nome"
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="email">Email</Label>
              <Input
                id="email"
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="o-teu-email@exemplo.com"
              />
            </div>
            <div className="flex flex-col gap-2">
              <Label htmlFor="password">Palavra-passe</Label>
              <Input
                id="password"
                type="password"
                required
                minLength={6}
                autoComplete="new-password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Mínimo 6 caracteres"
              />
            </div>
            <Button type="submit" disabled={busy} className="mt-2">
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <UserPlus className="mr-2 h-4 w-4" />}
              Criar conta
            </Button>
          </form>
          <p className="mt-6 text-center text-sm text-muted-foreground">
            Já tens conta?{" "}
            <Link to="/entrar" className="font-medium text-primary underline-offset-4 hover:underline">
              Entrar
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
