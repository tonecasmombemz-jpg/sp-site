import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/privacidade")({
  head: () => ({
    meta: [
      { title: "Política de privacidade — SUPER PROFS" },
      {
        name: "description",
        content: "Como o SUPER PROFS recolhe, usa e protege os teus dados.",
      },
      { property: "og:title", content: "Política de privacidade — SUPER PROFS" },
      { property: "og:description", content: "Como o SUPER PROFS recolhe, usa e protege os teus dados." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PrivacidadePage,
});

function PrivacidadePage() {
  return (
    <div className="container-page max-w-2xl py-10 md:py-14">
      <h1 className="font-display text-3xl font-bold md:text-4xl">Política de privacidade</h1>
      <p className="mt-2 text-sm text-muted-foreground">
        Última actualização: Outubro de 2026
      </p>

      <div className="mt-8 flex flex-col gap-6 text-sm leading-relaxed text-muted-foreground">
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">1. Dados que recolhemos</h2>
          <p className="mt-2">
            Quando crias conta, guardamos o teu nome, email e palavra-passe (protegida). No perfil
            podes indicar a tua escola e a universidade ou curso alvo. Ao estudar, registamos as
            tuas respostas aos exercícios e os resultados dos simulados para mostrar o teu progresso.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">2. Como usamos os dados</h2>
          <p className="mt-2">
            Usamos os teus dados para: mostrar o teu progresso no painel; corrigir testes
            automaticamente; personalizar conteúdos; e prestar apoio quando precisares. Não
            vendemos os teus dados a terceiros.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">3. Explicações com IA</h2>
          <p className="mt-2">
            Quando pedes uma explicação com IA, enviamos o conteúdo da pergunta e a tua resposta ao
            serviço de inteligência artificial para gerar a explicação. Não enviamos o teu nome nem
            o teu email.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">4. Segurança</h2>
          <p className="mt-2">
            Os dados são guardados de forma segura e o acesso à tua conta é feito com autenticação.
            Só tu podes ver o teu progresso e o teu perfil.
          </p>
        </section>
        <section>
          <h2 className="font-display text-lg font-semibold text-foreground">5. Os teus direitos</h2>
          <p className="mt-2">
            Podes ver e corrigir os teus dados na página de perfil e alterar a tua palavra-passe a
            qualquer momento. Se quiseres eliminar a tua conta e os teus dados, fala com a equipa
            do SUPER PROFS através da página de contactos.
          </p>
        </section>
      </div>
    </div>
  );
}
