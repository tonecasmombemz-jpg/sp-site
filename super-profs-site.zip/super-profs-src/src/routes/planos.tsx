import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Check, Sparkles } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from "@/components/ui/card";
import { useSession } from "@/hooks/use-session";
import { getActivePlans } from "@/lib/public-data";

const plansOptions = queryOptions({
  queryKey: ["planos"],
  queryFn: () => getActivePlans(),
});

export const Route = createFileRoute("/planos")({
  loader: ({ context }) => context.queryClient.ensureQueryData(plansOptions),
  head: () => ({
    meta: [
      { title: "Planos — SUPER PROFS" },
      {
        name: "description",
        content: "Planos do SUPER PROFS: começa grátis e desbloqueia simulados completos e recursos premium.",
      },
      { property: "og:title", content: "Planos — SUPER PROFS" },
      {
        property: "og:description",
        content: "Começa grátis e desbloqueia simulados completos e recursos premium.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PlanosPage,
});

function PlanosPage() {
  const { data } = useSuspenseQuery(plansOptions);
  const { plans } = data;
  const { user } = useSession();

  const handlePremium = () => {
    if (!user) {
      toast.info("Cria primeiro a tua conta grátis para poderes subscrever um plano.");
      return;
    }
    toast.info("As subscrições com pagamento estarão disponíveis em breve. Fala connosco para activar o premium.");
  };

  return (
    <div className="container-page py-10 md:py-14">
      <div className="mx-auto max-w-2xl text-center">
        <h1 className="font-display text-3xl font-bold md:text-4xl">Planos</h1>
        <p className="mt-3 text-muted-foreground">
          Começa grátis e, quando estiveres pronto, desbloqueia simulados completos e recursos premium.
        </p>
      </div>

      {plans.length === 0 ? (
        <Card className="mx-auto mt-8 max-w-xl">
          <CardContent className="py-10 text-center text-sm text-muted-foreground">
            Ainda não há planos publicados.
          </CardContent>
        </Card>
      ) : (
        <div className="mx-auto mt-10 grid max-w-4xl gap-6 md:grid-cols-2">
          {plans.map((p) => {
            const isFree = p.price_mzn === 0;
            return (
              <Card key={p.id} className={`shadow-card ${!isFree ? "border-brand/50" : ""}`}>
                <CardHeader>
                  <div className="flex items-center justify-between gap-2">
                    <CardTitle className="font-display text-xl">{p.name}</CardTitle>
                    {!isFree && (
                      <Badge className="bg-brand text-navy">
                        <Sparkles className="mr-1 h-3 w-3" /> Premium
                      </Badge>
                    )}
                  </div>
                  <p className="font-display text-4xl font-bold text-navy">
                    {isFree ? "Grátis" : `${p.price_mzn.toLocaleString("pt-PT")} MZN`}
                    {!isFree && <span className="text-base font-normal text-muted-foreground"> /mês</span>}
                  </p>
                  <CardDescription>{p.description}</CardDescription>
                </CardHeader>
                <CardContent className="flex flex-col gap-3">
                  <ul className="flex flex-col gap-2 text-sm">
                    {p.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <Check className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                  {isFree ? (
                    user ? (
                      <Button asChild className="mt-2">
                        <Link to="/disciplinas">Começar a estudar</Link>
                      </Button>
                    ) : (
                      <Button asChild className="mt-2">
                        <Link to="/registar">Criar conta grátis</Link>
                      </Button>
                    )
                  ) : (
                    <Button onClick={handlePremium} className="mt-2 bg-brand text-navy hover:bg-brand/90">
                      Activar premium
                    </Button>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
