// Server-only: acesso à chave de respostas, nunca exposto ao navegador.
// Importado apenas a partir de módulos de server functions (*.functions.ts /
// módulos client-safe), nunca directamente de rotas ou componentes.
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export interface AnswerKeyRow {
  id: string;
  question_id: string;
  content: string;
  is_correct: boolean;
}

export async function fetchAlternativesWithAnswers(questionIds: string[]): Promise<AnswerKeyRow[]> {
  if (questionIds.length === 0) return [];
  const { data, error } = await supabaseAdmin
    .from("question_alternatives")
    .select("id,question_id,content,is_correct")
    .in("question_id", questionIds);
  if (error) return [];
  return (data ?? []) as AnswerKeyRow[];
}

export async function fetchExplanationForQuestion(questionId: string): Promise<string | null> {
  const { data } = await supabaseAdmin
    .from("questions")
    .select("explanation")
    .eq("id", questionId)
    .eq("is_active", true)
    .maybeSingle();
  return (data?.explanation as string | undefined) ?? null;
}
