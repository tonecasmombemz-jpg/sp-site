import { createOpenAI } from "@ai-sdk/openai";
import { streamText, type ModelMessage } from "ai";

import { createLovableAiGatewayRunIdFetch, getLovableAiGatewayRunId } from "./run-id";

export const AI_UNAVAILABLE_MESSAGE =
  "As explicações com IA ainda não estão disponíveis. Por favor, tente novamente mais tarde.";

/**
 * Chama o gateway de IA do Lovable a partir do servidor (a chave nunca chega
 * ao navegador) e devolve o texto final da resposta.
 */
export async function explainWithGateway(
  request: Request,
  messages: ModelMessage[],
  instructions: string,
): Promise<string> {
  const apiKey = process.env["LOVABLE_API_KEY"];
  if (!apiKey) {
    throw new Error(AI_UNAVAILABLE_MESSAGE);
  }

  const baseURL = "https://ai.gateway.lovable.dev/v1";
  const modelId = "openai/gpt-6-astra";

  const runIdFetch = createLovableAiGatewayRunIdFetch(getLovableAiGatewayRunId(request));
  const provider = createOpenAI({
    baseURL,
    apiKey,
    headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    fetch: runIdFetch.fetch,
  });

  const result = streamText({
    model: provider.responses(modelId),
    instructions,
    messages,
    abortSignal: request.signal,
    providerOptions: {
      openai: {
        store: false,
        forceReasoning: true,
        reasoningEffort: "medium",
        reasoningSummary: "auto",
        include: ["reasoning.encrypted_content"],
      },
    },
  });

  // Consome o stream no servidor e devolve apenas o texto final.
  const text = await result.text;
  if (!text.trim()) {
    throw new Error(AI_UNAVAILABLE_MESSAGE);
  }
  return text;
}

/** Converte erros do gateway numa mensagem clara para o estudante. */
export function aiErrorMessage(error: unknown): string {
  const message = error instanceof Error ? error.message : "";
  const status = (error as { statusCode?: number })?.statusCode;
  if (message.includes("insufficient") || status === 402) {
    return "Os créditos de IA estão esgotados neste momento. Fale com a equipa do SUPER PROFS para reactivar esta funcionalidade.";
  }
  if (message.includes(AI_UNAVAILABLE_MESSAGE)) {
    return AI_UNAVAILABLE_MESSAGE;
  }
  return "Não foi possível obter a explicação com IA neste momento. Tente novamente.";
}
