import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";

export interface DisciplineItem {
  id: string;
  name: string;
  slug: string;
  description: string;
  icon: string;
}

export interface ThemeItem {
  id: string;
  name: string;
  description: string;
}

export interface ExamItem {
  id: string;
  title: string;
  description: string;
  duration_minutes: number | null;
  is_premium: boolean;
  is_demo: boolean;
  discipline_id: string | null;
}

export interface PlanItem {
  id: string;
  code: string;
  name: string;
  price_mzn: number;
  description: string;
  features: string[];
}

export interface VideoItem {
  id: string;
  title: string;
  description: string;
  youtube_url: string;
  discipline_name: string | null;
  discipline_slug: string | null;
}

export interface DisciplinesPageData {
  disciplines: Array<DisciplineItem & { themes: ThemeItem[] }>;
}

export function createPublicClient() {
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  return createClient(process.env["SUPABASE_URL"]!, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
          h.delete("Authorization");
        }
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const getLandingData = createServerFn({ method: "GET" }).handler(async () => {
  const sb = createPublicClient();
  const [disciplines, exams] = await Promise.all([
    sb.from("disciplines").select("id,name,slug,description,icon").eq("is_active", true).order("display_order"),
    sb
      .from("exams")
      .select("id,title,description,duration_minutes,is_premium,is_demo,discipline_id")
      .eq("is_published", true)
      .order("created_at", { ascending: false })
      .limit(3),
  ]);
  return {
    disciplines: (disciplines.data ?? []) as DisciplineItem[],
    exams: (exams.data ?? []) as ExamItem[],
  };
});

export const getDisciplinesWithThemes = createServerFn({ method: "GET" }).handler(async () => {
  const sb = createPublicClient();
  const [disciplines, themes] = await Promise.all([
    sb.from("disciplines").select("id,name,slug,description,icon").eq("is_active", true).order("display_order"),
    sb.from("themes").select("id,name,description,discipline_id").order("display_order"),
  ]);
  const themeList = (themes.data ?? []) as Array<ThemeItem & { discipline_id: string }>;
  const list = ((disciplines.data ?? []) as DisciplineItem[]).map((d) => ({
    ...d,
    themes: themeList.filter((t) => t.discipline_id === d.id),
  }));
  return { disciplines: list } satisfies DisciplinesPageData;
});

export const getPublishedVideos = createServerFn({ method: "GET" }).handler(async () => {
  const sb = createPublicClient();
  const { data } = await sb
    .from("videos")
    .select("id,title,description,youtube_url,discipline:discipline_id(name,slug)")
    .eq("is_published", true)
    .order("created_at", { ascending: false });
  const videos = (data ?? []).map((v) => {
    const row = v as unknown as { id: string; title: string; description: string; youtube_url: string; discipline: { name: string; slug: string } | null };
    return {
      id: row.id,
      title: row.title,
      description: row.description,
      youtube_url: row.youtube_url,
      discipline_name: row.discipline?.name ?? null,
      discipline_slug: row.discipline?.slug ?? null,
    } satisfies VideoItem;
  });
  return { videos };
});

export const getActivePlans = createServerFn({ method: "GET" }).handler(async () => {
  const sb = createPublicClient();
  const { data } = await sb.from("plans").select("id,code,name,price_mzn,description,features").eq("is_active", true).order("price_mzn");
  const plans = ((data ?? []) as Array<Omit<PlanItem, "features"> & { features: string[] | null }>).map((p) => ({
    ...p,
    features: p.features ?? [],
  }));
  return { plans: plans as PlanItem[] };
});
