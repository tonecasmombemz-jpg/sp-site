import { createServerFn } from "@tanstack/react-start";
import { getRequest } from "@tanstack/react-start/server";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { ModelMessage } from "ai";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { aiErrorMessage, explainWithGateway } from "@/lib/ai/responses";
import { createPublicClient } from "@/lib/public-data";

// ============= Tipos partilhados =============

export interface AlternativeOption {
  id: string;
  content: string;
  display_order: number;
}

export interface PracticeQuestion {
  id: string;
  statement: string;
  difficulty: string;
  is_premium: boolean;
  is_demo: boolean;
  alternatives: AlternativeOption[];
}

export interface ExamQuestionView {
  id: string;
  statement: string;
  difficulty: string;
  explanation: string;
  alternatives: AlternativeOption[];
  correct_alternative_id?: string | null;
}

export interface ExamDetail {
  id: string;
  title: string;
  description: string;
  duration_minutes: number | null;
  is_premium: boolean;
  is_demo: boolean;
  discipline_name: string | null;
}

export interface ExamResultItem {
  questionId: string;
  statement: string;
  selectedId: string | null;
  selectedContent: string | null;
  correctId: string | null;
  correctContent: string | null;
  isCorrect: boolean;
  explanation: string;
}

export interface ExamResult {
  attemptId?: string;
  total: number;
  correctCount: number;
  scorePercent: number;
  items: ExamResultItem[];
}

type PublicClient = ReturnType<typeof createPublicClient>;
type AuthContext = { supabase: SupabaseClient; userId: string };

// ============= Listagem de simulados =============

export const getExamsList = createServerFn({ method: "GET" }).handler(async () => {
  const sb = createPublicClient();
  const { data } = await sb
    .from("exams")
    .select("id,title,description,duration_minutes,is_premium,is_demo,discipline:discipline_id(name,slug)")
    .eq("is_published", true)
    .order("created_at", { ascending: false });
  const exams = (data ?? []).map((e) => {
    const row = e as unknown as {
      id: string;
      title: string;
      description: string;
      duration_minutes: number | null;
      is_premium: boolean;
      is_demo: boolean;
      discipline: { name: string; slug: string } | null;
    };
    return {
      id: row.id,
      title: row.title,
      description: row.description,
      duration_minutes: row.duration_minutes,
      is_premium: row.is_premium,
      is_demo: row.is_demo,
      discipline_name: row.discipline?.name ?? null,
      discipline_slug: row.discipline?.slug ?? null,
    };
  });
  return { exams };
});

// ============= Disciplina + temas =============

export const getDisciplineBySlug = createServerFn({ method: "GET" })
  .inputValidator((slug: string) => slug)
  .handler(async ({ data }) => {
    const sb = createPublicClient();
    const { data: discipline } = await sb
      .from("disciplines")
      .select("id,name,slug,description,icon")
      .eq("slug", data)
      .eq("is_active", true)
      .maybeSingle();
    if (!discipline) return null;

    const [themesRes, questionsRes, examsRes] = await Promise.all([
      sb.from("themes").select("id,name,description").eq("discipline_id", discipline.id).order("display_order"),
      sb.from("questions").select("id,theme_id,difficulty,is_premium").eq("discipline_id", discipline.id).eq("is_active", true),
      sb
        .from("exams")
        .select("id,title,description,duration_minutes,is_premium,is_demo")
        .eq("discipline_id", discipline.id)
        .eq("is_published", true)
        .order("created_at", { ascending: false }),
    ]);

    const themes = (themesRes.data ?? []).map((t) => {
      const qs = (questionsRes.data ?? []).filter((q) => q.theme_id === t.id);
      return {
        id: t.id,
        name: t.name,
        description: t.description,
        question_count: qs.length,
        premium_count: qs.filter((q) => q.is_premium).length,
      };
    });

    return { discipline, themes, exams: examsRes.data ?? [] };
  });

// ============= Praticar por tema =============

async function fetchQuestionsForTheme(
  sb: PublicClient,
  themeId: string,
  includePremium: boolean,
): Promise<PracticeQuestion[]> {
  const base = sb
    .from("questions")
    .select("id,statement,difficulty,is_premium,is_demo")
    .eq("is_active", true)
    .eq("theme_id", themeId);
  const { data: questions } = includePremium ? await base : await base.eq("is_premium", false);
  const list = questions ?? [];
  const ids = list.map((q) => q.id as string);
  const alternatives = ids.length
    ? await sb
        .from("question_alternatives_public")
        .select("id,question_id,content,display_order")
        .in("question_id", ids)
    : { data: [] as Array<{ id: string; question_id: string; content: string; display_order: number }> };

  const byQuestion = new Map<string, AlternativeOption[]>();
  for (const a of (alternatives.data ?? []) as Array<{
    id: string;
    question_id: string;
    content: string;
    display_order: number;
  }>) {
    const arr = byQuestion.get(a.question_id) ?? [];
    arr.push({ id: a.id, content: a.content, display_order: a.display_order });
    byQuestion.set(a.question_id, arr);
  }

  return list.map((q) => ({
    id: q.id as string,
    statement: q.statement as string,
    difficulty: q.difficulty as string,
    is_premium: q.is_premium as boolean,
    is_demo: q.is_demo as boolean,
    alternatives: (byQuestion.get(q.id as string) ?? []).sort((x, y) => x.display_order - y.display_order),
  }));
}

async function fetchThemePractice(sb: PublicClient, themeId: string, includePremium: boolean) {
  const { data: theme } = await sb
    .from("themes")
    .select("id,name,description,discipline:discipline_id(name,slug)")
    .eq("id", themeId)
    .maybeSingle();
  if (!theme) return null;
  const row = theme as unknown as {
    id: string;
    name: string;
    description: string;
    discipline: { name: string; slug: string } | null;
  };
  const questions = await fetchQuestionsForTheme(sb, themeId, includePremium);
  return {
    theme: { id: row.id, name: row.name, description: row.description },
    discipline: row.discipline ? { name: row.discipline.name, slug: row.discipline.slug } : null,
    questions,
  };
}

export const getThemePractice = createServerFn({ method: "GET" })
  .inputValidator((input: { themeId: string }) => input)
  .handler(async ({ data }) => fetchThemePractice(createPublicClient(), data.themeId, false));

async function isPremiumUser(context: AuthContext): Promise<boolean> {
  const [{ data: profile }, { data: subs }] = await Promise.all([
    context.supabase.from("profiles").select("plan").eq("id", context.userId).maybeSingle(),
    context.supabase.from("subscriptions").select("id").eq("user_id", context.userId).eq("status", "active").limit(1),
  ]);
  return profile?.plan === "premium" || (subs?.length ?? 0) > 0;
}

export const getThemePracticePremium = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { themeId: string }) => input)
  .handler(async ({ data, context }) => {
    if (!(await isPremiumUser(context))) {
      return { allowed: false as const, questions: [] as PracticeQuestion[] };
    }
    const result = await fetchThemePractice(createPublicClient(), data.themeId, true);
    return { allowed: true as const, questions: result?.questions ?? [] };
  });

// ============= Verificar resposta de exercício =============

export interface AnswerCheck {
  isCorrect: boolean;
  correctAlternativeId: string | null;
  explanation: string;
}

export const checkExerciseAnswer = createServerFn({ method: "POST" })
  .inputValidator((input: { questionId: string; alternativeId: string }) => input)
  .handler(async ({ data }) => {
    // A chave de respostas nunca é exposta ao navegador: a correcção acontece
    // sempre no servidor.
    const { fetchAlternativesWithAnswers, fetchExplanationForQuestion } = await import(
      "@/lib/server/answer-key.server"
    );
    const [alternatives, explanation] = await Promise.all([
      fetchAlternativesWithAnswers([data.questionId]),
      fetchExplanationForQuestion(data.questionId),
    ]);
    if (explanation === null) {
      return { isCorrect: false, correctAlternativeId: null, explanation: "Esta pergunta já não está disponível." };
    }
    const correct = alternatives.find((a) => a.is_correct);
    return {
      isCorrect: correct?.id === data.alternativeId,
      correctAlternativeId: correct?.id ?? null,
      explanation,
    };
  });

export const saveExerciseAnswer = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { questionId: string; alternativeId: string }) => input)
  .handler(async ({ data, context }) => {
    const { fetchAlternativesWithAnswers } = await import("@/lib/server/answer-key.server");
    const alternatives = await fetchAlternativesWithAnswers([data.questionId]);
    const isCorrect = alternatives.some((a) => a.id === data.alternativeId && a.is_correct);
    const { error } = await context.supabase.from("exercise_attempts").insert({
      user_id: context.userId,
      question_id: data.questionId,
      selected_alternative_id: data.alternativeId,
      is_correct: isCorrect,
    });
    return { saved: !error, isCorrect };
  });

// ============= Simulado: perguntas e submissão =============

async function fetchExamQuestions(
  sb: PublicClient,
  examId: string,
): Promise<{ exam: ExamDetail; questions: ExamQuestionView[] } | null> {
  const { data: examRow } = await sb
    .from("exams")
    .select("id,title,description,duration_minutes,is_premium,is_demo,discipline:discipline_id(name,slug)")
    .eq("id", examId)
    .eq("is_published", true)
    .maybeSingle();
  if (!examRow) return null;
  const row = examRow as unknown as {
    id: string;
    title: string;
    description: string;
    duration_minutes: number | null;
    is_premium: boolean;
    is_demo: boolean;
    discipline: { name: string; slug: string } | null;
  };
  const exam: ExamDetail = {
    id: row.id,
    title: row.title,
    description: row.description,
    duration_minutes: row.duration_minutes,
    is_premium: row.is_premium,
    is_demo: row.is_demo,
    discipline_name: row.discipline?.name ?? null,
  };

  const { data: eqs } = await sb
    .from("exam_questions")
    .select("question_id,display_order")
    .eq("exam_id", examId)
    .order("display_order");
  const ordered = eqs ?? [];
  const ids = ordered.map((r) => r.question_id as string);
  if (ids.length === 0) return { exam, questions: [] };

  const [questionsRes, alternativesRes] = await Promise.all([
    sb.from("questions").select("id,statement,difficulty,explanation").in("id", ids).eq("is_active", true),
    sb
      .from("question_alternatives_public")
      .select("id,question_id,content,display_order")
      .in("question_id", ids),
  ]);

  const altsByQuestion = new Map<string, AlternativeOption[]>();
  for (const a of (alternativesRes.data ?? []) as Array<{
    id: string;
    question_id: string;
    content: string;
    display_order: number;
  }>) {
    const arr = altsByQuestion.get(a.question_id) ?? [];
    arr.push({ id: a.id, content: a.content, display_order: a.display_order });
    altsByQuestion.set(a.question_id, arr);
  }

  // Só nos simulados de demonstração se revela a resposta certa (o corrector
  // dos simulados normais é feito no servidor, na submissão).
  let correctIdByQuestion = new Map<string, string>();
  if (exam.is_demo) {
    const { fetchAlternativesWithAnswers } = await import("@/lib/server/answer-key.server");
    const alternatives = await fetchAlternativesWithAnswers(ids);
    const correctByQuestion = new Map<string, string>();
    for (const c of alternatives) {
      if (c.is_correct) correctByQuestion.set(c.question_id, c.id);
    }
    correctIdByQuestion = correctByQuestion;
  }

  const qMap = new Map((questionsRes.data ?? []).map((q) => [q.id as string, q]));
  const questions: ExamQuestionView[] = [];
  for (const r of ordered) {
    const q = qMap.get(r.question_id as string);
    if (!q) continue;
    const alternatives = (altsByQuestion.get(q.id as string) ?? []).sort(
      (x, y) => x.display_order - y.display_order,
    );
    questions.push({
      id: q.id as string,
      statement: q.statement as string,
      difficulty: q.difficulty as string,
      explanation: q.explanation as string,
      alternatives,
      ...(exam.is_demo ? { correct_alternative_id: correctIdByQuestion.get(q.id as string) ?? null } : {}),
    });
  }
  return { exam, questions };
}

export const getExamQuestions = createServerFn({ method: "GET" })
  .inputValidator((examId: string) => examId)
  .handler(async ({ data }) => fetchExamQuestions(createPublicClient(), data));

export interface ExamQuestionsForUser {
  exam: ExamDetail;
  allowed: boolean;
  questions: ExamQuestionView[];
}

export const getExamQuestionsForUser = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((examId: string) => examId)
  .handler(async ({ data, context }): Promise<ExamQuestionsForUser | null> => {
    const base = await fetchExamQuestions(createPublicClient(), data);
    if (!base) return null;
    if (base.exam.is_premium && !(await isPremiumUser(context))) {
      return { exam: base.exam, allowed: false, questions: [] };
    }
    return { exam: base.exam, allowed: true, questions: base.questions };
  });

export const submitExamAttempt = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { examId: string; answers: Array<{ questionId: string; alternativeId: string }> }) => input)
  .handler(async ({ data, context }): Promise<{ error: string } | ExamResult> => {
    const { data: exam } = await context.supabase
      .from("exams")
      .select("id,is_premium")
      .eq("id", data.examId)
      .eq("is_published", true)
      .maybeSingle();
    if (!exam) return { error: "Este simulado já não está disponível." };
    if (exam.is_premium && !(await isPremiumUser(context))) {
      return { error: "Este simulado é premium. Subscreve um plano para o resolver." };
    }

    const { data: eqs } = await context.supabase
      .from("exam_questions")
      .select("question_id")
      .eq("exam_id", data.examId);
    const ids = (eqs ?? []).map((r) => r.question_id as string);
    const total = ids.length;

    const { fetchAlternativesWithAnswers } = await import("@/lib/server/answer-key.server");
    const [questionsRes, alternatives] = await Promise.all([
      context.supabase.from("questions").select("id,statement,explanation").in("id", ids).eq("is_active", true),
      fetchAlternativesWithAnswers(ids),
    ]);

    const correctByQuestion = new Map<string, { id: string; content: string }>();
    const contentByAlternative = new Map<string, string>();
    for (const a of alternatives) {
      contentByAlternative.set(a.id, a.content);
      if (a.is_correct) correctByQuestion.set(a.question_id, { id: a.id, content: a.content });
    }

    const answerMap = new Map(data.answers.map((a) => [a.questionId, a.alternativeId]));
    const qList = (questionsRes.data ?? []) as Array<{ id: string; statement: string; explanation: string }>;
    const items: ExamResultItem[] = qList.map((q) => {
      const selectedId = answerMap.get(q.id as string) ?? null;
      const correct = correctByQuestion.get(q.id as string);
      const isCorrect = !!selectedId && correct?.id === selectedId;
      return {
        questionId: q.id as string,
        statement: q.statement as string,
        selectedId,
        selectedContent: selectedId ? contentByAlternative.get(selectedId) ?? null : null,
        correctId: correct?.id ?? null,
        correctContent: correct?.content ?? null,
        isCorrect,
        explanation: q.explanation as string,
      };
    });
    const correctCount = items.filter((i) => i.isCorrect).length;
    const scorePercent = total ? Math.round((correctCount / total) * 100) : 0;

    const { data: attempt, error } = await context.supabase
      .from("exam_attempts")
      .insert({
        exam_id: data.examId,
        user_id: context.userId,
        total_questions: total,
        correct_count: correctCount,
        score_percent: scorePercent,
        submitted_at: new Date().toISOString(),
      })
      .select("id")
      .single();
    if (error || !attempt) return { error: "Não foi possível guardar o resultado. Tenta novamente." };

    const rows = data.answers.map((a) => ({
      attempt_id: attempt.id as string,
      question_id: a.questionId,
      selected_alternative_id: a.alternativeId,
      is_correct: correctByQuestion.get(a.questionId)?.id === a.alternativeId,
    }));
    if (rows.length) {
      await context.supabase.from("attempt_answers").insert(rows);
    }

    return { attemptId: attempt.id as string, total, correctCount, scorePercent, items };
  });

// ============= Explicação com IA =============

export const explainQuestion = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (input: {
      statement: string;
      alternatives: string[];
      selected: string | null;
      isCorrect: boolean;
      discipline: string;
      theme: string;
    }) => input,
  )
  .handler(async ({ data }) => {
    const instructions =
      "És um professor moçambicano paciente e claro. Explica em português simples (português de Moçambique), passo a passo, para um estudante a preparar o exame de admissão. Usa frases curtas e no máximo 200 palavras. Não uses markdown com cabeçalhos; escreve texto simples.";
    const content = [
      `Disciplina: ${data.discipline || "—"}`,
      `Tema: ${data.theme || "—"}`,
      `Pergunta: ${data.statement}`,
      "Opções:",
      ...data.alternatives.map((a, i) => `${i + 1}. ${a}`),
      `Resposta escolhida pelo estudante: ${data.selected ?? "nenhuma"} (${data.isCorrect ? "correcta" : "incorrecta"})`,
      "Explica porque a resposta correcta é a certa e como se chega a ela, passo a passo.",
    ].join("\n");
    const messages: ModelMessage[] = [{ role: "user", content }];
    try {
      const request = getRequest();
      const text = await explainWithGateway(request, messages, instructions);
      return { explanation: text };
    } catch (error) {
      return { error: aiErrorMessage(error) };
    }
  });

// ============= Painel e perfil do estudante =============

export interface DashboardData {
  profile: {
    full_name: string;
    plan: string;
    school: string | null;
    target_exam: string | null;
  } | null;
  exercise: { total: number; correct: number };
  attempts: Array<{
    id: string;
    started_at: string;
    submitted_at: string | null;
    total_questions: number;
    correct_count: number;
    score_percent: number;
    exam_title: string | null;
  }>;
  subscription: {
    status: string;
    plan_name: string | null;
    expires_at: string | null;
  } | null;
}

export const getMyDashboard = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<DashboardData> => {
    const [profileRes, exerciseRes, attemptsRes, subRes] = await Promise.all([
      context.supabase
        .from("profiles")
        .select("full_name,plan,school,target_exam")
        .eq("id", context.userId)
        .maybeSingle(),
      context.supabase.from("exercise_attempts").select("is_correct"),
      context.supabase
        .from("exam_attempts")
        .select("id,started_at,submitted_at,total_questions,correct_count,score_percent,exam:exam_id(title)")
        .eq("user_id", context.userId)
        .order("started_at", { ascending: false })
        .limit(8),
      context.supabase
        .from("subscriptions")
        .select("status,expires_at,plan:plan_id(name)")
        .eq("user_id", context.userId)
        .order("created_at", { ascending: false })
        .limit(1),
    ]);

    const exerciseRows = (exerciseRes.data ?? []) as Array<{ is_correct: boolean }>;
    const attempts = (attemptsRes.data ?? []).map((a) => {
      const row = a as {
        id: string;
        started_at: string;
        submitted_at: string | null;
        total_questions: number;
        correct_count: number;
        score_percent: number;
        exam: { title: string } | Array<{ title: string }> | null;
      };
      const examTitle = Array.isArray(row.exam) ? row.exam[0]?.title ?? null : row.exam?.title ?? null;
      return {
        id: row.id,
        started_at: row.started_at,
        submitted_at: row.submitted_at,
        total_questions: row.total_questions,
        correct_count: row.correct_count,
        score_percent: row.score_percent,
        exam_title: examTitle,
      };
    });
    const subRow = (subRes.data ?? [])[0] as {
      status: string;
      expires_at: string | null;
      plan: { name: string } | Array<{ name: string }> | null;
    } | undefined;
    const subPlan = subRow ? (Array.isArray(subRow.plan) ? subRow.plan[0]?.name ?? null : subRow.plan?.name ?? null) : null;

    return {
      profile: (profileRes.data as DashboardData["profile"]) ?? null,
      exercise: {
        total: exerciseRows.length,
        correct: exerciseRows.filter((r) => r.is_correct).length,
      },
      attempts,
      subscription: subRow ? { status: subRow.status, plan_name: subPlan, expires_at: subRow.expires_at } : null,
    };
  });

export const updateMyProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { fullName: string; school: string | null; targetExam: string | null }) => input)
  .handler(async ({ data, context }) => {
    const { error } = await context.supabase
      .from("profiles")
      .update({
        full_name: data.fullName,
        school: data.school,
        target_exam: data.targetExam,
        updated_at: new Date().toISOString(),
      })
      .eq("id", context.userId);
    return { ok: !error, error: error?.message ?? null };
  });
