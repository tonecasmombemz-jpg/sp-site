import { Link } from "@tanstack/react-router";
import { Facebook, Instagram, Youtube, GraduationCap } from "lucide-react";
import logoUrl from "@/assets/logo.png";

export function SiteFooter() {
  return (
    <footer className="hero-gradient mt-auto text-primary-foreground">
      <div className="container-page grid gap-10 py-12 md:grid-cols-4">
        <div>
          <div className="flex items-center gap-2.5">
            <img src={logoUrl} alt="" className="h-9 w-9 rounded-md bg-white/10 p-1" width={36} height={36} />
            <span className="font-display text-lg font-bold">
              SUPER <span className="text-brand">PROFS</span>
            </span>
          </div>
          <p className="mt-3 text-sm text-primary-foreground/75">
            A tua aprovação começa aqui! Preparação para os exames de admissão às universidades
            em Moçambique.
          </p>
          <div className="mt-4 flex gap-3">
            <a href="#" aria-label="Facebook" className="rounded-full bg-white/10 p-2 transition-colors hover:bg-white/20">
              <Facebook className="h-4 w-4" />
            </a>
            <a href="#" aria-label="Instagram" className="rounded-full bg-white/10 p-2 transition-colors hover:bg-white/20">
              <Instagram className="h-4 w-4" />
            </a>
            <a href="#" aria-label="YouTube" className="rounded-full bg-white/10 p-2 transition-colors hover:bg-white/20">
              <Youtube className="h-4 w-4" />
            </a>
          </div>
          <p className="mt-3 text-xs text-primary-foreground/60">
            As ligações das redes sociais devem ser configuradas com os endereços oficiais do
            SUPER PROFS.
          </p>
        </div>

        <nav aria-label="Rodapé — navegação">
          <h3 className="font-display text-sm font-semibold text-brand-soft">Plataforma</h3>
          <ul className="mt-3 space-y-2 text-sm text-primary-foreground/80">
            <li><Link to="/disciplinas" className="hover:text-brand-soft">Disciplinas</Link></li>
            <li><Link to="/simulados" className="hover:text-brand-soft">Simulados</Link></li>
            <li><Link to="/videos" className="hover:text-brand-soft">Vídeos educativos</Link></li>
            <li><Link to="/planos" className="hover:text-brand-soft">Planos e preços</Link></li>
          </ul>
        </nav>

        <nav aria-label="Rodapé — contactos">
          <h3 className="font-display text-sm font-semibold text-brand-soft">Contactos</h3>
          <ul className="mt-3 space-y-2 text-sm text-primary-foreground/80">
            <li><Link to="/contactos" className="hover:text-brand-soft">Página de contactos</Link></li>
            <li className="text-primary-foreground/60">
              Telefone, e-mail e morada: a definir pelo administrador.
            </li>
          </ul>
        </nav>

        <nav aria-label="Rodapé — legal">
          <h3 className="font-display text-sm font-semibold text-brand-soft">Informação legal</h3>
          <ul className="mt-3 space-y-2 text-sm text-primary-foreground/80">
            <li><Link to="/termos" className="hover:text-brand-soft">Termos de utilização</Link></li>
            <li><Link to="/privacidade" className="hover:text-brand-soft">Política de privacidade</Link></li>
          </ul>
          <div className="mt-4 flex items-center gap-2 text-xs text-primary-foreground/60">
            <GraduationCap className="h-4 w-4 text-brand" />
            <span>© {new Date().getFullYear()} SUPER PROFS</span>
          </div>
        </nav>
      </div>
    </footer>
  );
}
