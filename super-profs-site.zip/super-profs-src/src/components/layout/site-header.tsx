import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useState, type ComponentType } from "react";
import {
  Atom, BookOpen, FlaskConical, Globe, Leaf, Sigma,
  LogOut, Menu, UserRound, ChevronDown,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { useSession } from "@/hooks/use-session";
import { supabase } from "@/integrations/supabase/client";
import logoUrl from "@/assets/logo.png";

const NAV_LINKS = [
  { to: "/", label: "Início" },
  { to: "/disciplinas", label: "Disciplinas" },
  { to: "/simulados", label: "Simulados" },
  { to: "/videos", label: "Vídeos" },
  { to: "/planos", label: "Planos" },
] as const;

export const DISCIPLINE_ICONS: Record<string, ComponentType<{ className?: string }>> = {
  sigma: Sigma,
  atom: Atom,
  flask: FlaskConical,
  book: BookOpen,
  leaf: Leaf,
  globe: Globe,
};

export function SiteHeader() {
  const { user, loading } = useSession();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleSignOut = async () => {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    setMenuOpen(false);
    navigate({ to: "/entrar", replace: true });
  };

  const fullName = (user?.user_metadata?.["full_name"] as string | undefined) ?? "";
  const email = user?.email ?? "";

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/85 backdrop-blur-md">
      <div className="container-page flex h-16 items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-2.5" aria-label="SUPER PROFS — início">
          <img src={logoUrl} alt="" className="h-9 w-9" width={36} height={36} />
          <span className="font-display text-lg font-bold tracking-tight">
            SUPER <span className="text-brand">PROFS</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex" aria-label="Navegação principal">
          {NAV_LINKS.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
              activeOptions={{ exact: link.to === "/" }}
              activeProps={{ className: "text-foreground bg-secondary/70" }}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="hidden items-center gap-2 md:flex">
          {loading ? (
            <div className="h-9 w-36 animate-pulse rounded-md bg-muted" />
          ) : user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="gap-2">
                  <UserRound className="h-4 w-4" />
                  <span className="max-w-32 truncate">{fullName || email}</span>
                  <ChevronDown className="h-3.5 w-3.5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-52">
                <DropdownMenuLabel className="truncate">{email}</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate({ to: "/painel" })}>
                  O meu painel
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate({ to: "/perfil" })}>
                  Perfil
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut} className="text-destructive">
                  <LogOut className="mr-2 h-4 w-4" /> Terminar sessão
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button variant="ghost" onClick={() => navigate({ to: "/entrar" })}>
                Entrar
              </Button>
              <Button onClick={() => navigate({ to: "/registar" })}>Criar conta</Button>
            </>
          )}
        </div>

        <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="outline" size="icon" aria-label="Abrir menu">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-72">
            <SheetTitle className="flex items-center gap-2 font-display text-base font-bold">
              <img src={logoUrl} alt="" className="h-8 w-8" width={32} height={32} />
              SUPER <span className="text-brand">PROFS</span>
            </SheetTitle>
            <nav className="mt-6 flex flex-col gap-1" aria-label="Navegação para telemóvel">
              {NAV_LINKS.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  onClick={() => setMenuOpen(false)}
                  className="rounded-md px-3 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-secondary"
                >
                  {link.label}
                </Link>
              ))}
            </nav>
            <div className="mt-6 flex flex-col gap-2 border-t border-border pt-4">
              {user ? (
                <>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setMenuOpen(false);
                      navigate({ to: "/painel" });
                    }}
                  >
                    O meu painel
                  </Button>
                  <Button
                    variant="ghost"
                    onClick={() => {
                      setMenuOpen(false);
                      navigate({ to: "/perfil" });
                    }}
                  >
                    Perfil
                  </Button>
                  <Button variant="destructive" onClick={handleSignOut}>
                    Terminar sessão
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setMenuOpen(false);
                      navigate({ to: "/entrar" });
                    }}
                  >
                    Entrar
                  </Button>
                  <Button
                    onClick={() => {
                      setMenuOpen(false);
                      navigate({ to: "/registar" });
                    }}
                  >
                    Criar conta
                  </Button>
                </>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
