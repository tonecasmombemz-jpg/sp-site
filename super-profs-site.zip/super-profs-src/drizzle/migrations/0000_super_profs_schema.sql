-- ============ SUPER PROFS — esquema inicial ============

create type public.app_role as enum ('admin', 'moderator', 'user');

-- ---------- Perfis ----------
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  avatar_url text,
  plan text not null default 'free' check (plan in ('free','premium')),
  school text,
  target_exam text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------- Funções (papéis) ----------
create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role app_role not null default 'user',
  unique (user_id, role)
);

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.user_roles
    where user_id = _user_id and role = _role
  )
$$;

-- Novo utilizador -> criar perfil + função 'user'
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', ''));
  insert into public.user_roles (user_id, role) values (new.id, 'user');
  return new;
end;
$$;

create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- updated_at automático nos perfis
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end;
$$;
create trigger profiles_updated_at before update on public.profiles
for each row execute function public.touch_updated_at();

-- ---------- Disciplinas e temas ----------
create table public.disciplines (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  description text not null default '',
  icon text not null default 'book',
  display_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table public.themes (
  id uuid primary key default gen_random_uuid(),
  discipline_id uuid not null references public.disciplines(id) on delete cascade,
  name text not null,
  description text not null default '',
  display_order int not null default 0
);

-- ---------- Perguntas e alternativas ----------
create table public.questions (
  id uuid primary key default gen_random_uuid(),
  discipline_id uuid not null references public.disciplines(id) on delete cascade,
  theme_id uuid references public.themes(id) on delete set null,
  difficulty text not null default 'medio' check (difficulty in ('facil','medio','dificil')),
  statement text not null,
  explanation text not null default '',
  is_premium boolean not null default false,
  is_active boolean not null default true,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

-- As respostas correctas nunca são lidas pelo navegador:
-- sem GRANT para anon/authenticated, apenas o servidor acede.
create table public.question_alternatives (
  id uuid primary key default gen_random_uuid(),
  question_id uuid not null references public.questions(id) on delete cascade,
  content text not null,
  is_correct boolean not null default false,
  display_order int not null default 0
);

-- ---------- Exames / simulados ----------
create table public.exams (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  discipline_id uuid references public.disciplines(id) on delete set null,
  duration_minutes int,
  is_published boolean not null default false,
  is_premium boolean not null default false,
  is_demo boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.exam_questions (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  display_order int not null default 0
);

create table public.exam_attempts (
  id uuid primary key default gen_random_uuid(),
  exam_id uuid not null references public.exams(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  started_at timestamptz not null default now(),
  submitted_at timestamptz,
  total_questions int not null default 0,
  correct_count int not null default 0,
  score_percent numeric not null default 0
);

create table public.attempt_answers (
  id uuid primary key default gen_random_uuid(),
  attempt_id uuid not null references public.exam_attempts(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  selected_alternative_id uuid,
  is_correct boolean not null default false
);

-- ---------- Exercícios práticos ----------
create table public.exercise_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  selected_alternative_id uuid,
  is_correct boolean not null default false,
  created_at timestamptz not null default now()
);

-- ---------- Favoritos ----------
create table public.favorites (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  question_id uuid not null references public.questions(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (user_id, question_id)
);

-- ---------- Vídeos educativos ----------
create table public.videos (
  id uuid primary key default gen_random_uuid(),
  discipline_id uuid references public.disciplines(id) on delete set null,
  theme_id uuid references public.themes(id) on delete set null,
  title text not null,
  description text not null default '',
  youtube_url text not null,
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);

-- ---------- Planos, subscrições e pagamentos ----------
create table public.plans (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  price_mzn numeric not null default 0,
  description text not null default '',
  features jsonb not null default '[]',
  is_active boolean not null default true
);

create table public.subscriptions (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  plan_id uuid not null references public.plans(id),
  status text not null default 'pending' check (status in ('pending','active','expired','cancelled')),
  started_at timestamptz,
  expires_at timestamptz,
  provider text,
  provider_reference text,
  created_at timestamptz not null default now()
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  plan_id uuid references public.plans(id),
  amount numeric not null,
  currency text not null default 'MZN',
  provider text,
  provider_reference text,
  status text not null default 'pending' check (status in ('pending','confirmed','failed','refunded')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ============ GRANTs ============
grant select on public.profiles to authenticated;
grant update on public.profiles to authenticated;
grant all on public.profiles to service_role;

grant select on public.user_roles to authenticated;
grant all on public.user_roles to service_role;

grant select on public.disciplines to anon, authenticated;
grant all on public.disciplines to service_role;

grant select on public.themes to anon, authenticated;
grant all on public.themes to service_role;

grant select on public.questions to anon, authenticated;
grant all on public.questions to service_role;

-- alternativas: apenas service_role (protege as respostas correctas)
grant all on public.question_alternatives to service_role;

grant select on public.exams to anon, authenticated;
grant all on public.exams to service_role;

grant select on public.exam_questions to anon, authenticated;
grant all on public.exam_questions to service_role;

grant select, insert, update on public.exam_attempts to authenticated;
grant all on public.exam_attempts to service_role;

grant select, insert on public.attempt_answers to authenticated;
grant all on public.attempt_answers to service_role;

grant select, insert on public.exercise_attempts to authenticated;
grant all on public.exercise_attempts to service_role;

grant select, insert, delete on public.favorites to authenticated;
grant all on public.favorites to service_role;

grant select on public.videos to anon, authenticated;
grant all on public.videos to service_role;

grant select on public.plans to anon, authenticated;
grant all on public.plans to service_role;

grant select on public.subscriptions to authenticated;
grant all on public.subscriptions to service_role;

grant select on public.payments to authenticated;
grant all on public.payments to service_role;

-- ============ RLS ============
alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.disciplines enable row level security;
alter table public.themes enable row level security;
alter table public.questions enable row level security;
alter table public.question_alternatives enable row level security;
alter table public.exams enable row level security;
alter table public.exam_questions enable row level security;
alter table public.exam_attempts enable row level security;
alter table public.attempt_answers enable row level security;
alter table public.exercise_attempts enable row level security;
alter table public.favorites enable row level security;
alter table public.videos enable row level security;
alter table public.plans enable row level security;
alter table public.subscriptions enable row level security;
alter table public.payments enable row level security;

create policy "Perfis: ver o próprio perfil" on public.profiles
  for select to authenticated using (id = auth.uid());
create policy "Perfis: actualizar o próprio perfil" on public.profiles
  for update to authenticated using (id = auth.uid()) with check (id = auth.uid());

create policy "Funções: consultar próprias funções" on public.user_roles
  for select to authenticated using (user_id = auth.uid());

create policy "Disciplinas activas visíveis" on public.disciplines
  for select to anon, authenticated using (is_active);

create policy "Temas visíveis" on public.themes
  for select to anon, authenticated using (true);

create policy "Perguntas activas visíveis" on public.questions
  for select to anon, authenticated using (is_active);

-- question_alternatives: sem política -> nenhum acesso via Data API

create policy "Exames publicados visíveis" on public.exams
  for select to anon, authenticated using (is_published);

create policy "Perguntas de exames publicados visíveis" on public.exam_questions
  for select to anon, authenticated using (
    exists (select 1 from public.exams e where e.id = exam_id and e.is_published)
  );

create policy "Tentativas: do próprio estudante" on public.exam_attempts
  for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "Respostas de tentativa: do próprio estudante" on public.attempt_answers
  for all to authenticated using (
    exists (select 1 from public.exam_attempts a where a.id = attempt_id and a.user_id = auth.uid())
  ) with check (
    exists (select 1 from public.exam_attempts a where a.id = attempt_id and a.user_id = auth.uid())
  );

create policy "Exercícios: do próprio estudante" on public.exercise_attempts
  for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "Favoritos: do próprio estudante" on public.favorites
  for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy "Vídeos publicados visíveis" on public.videos
  for select to anon, authenticated using (is_published);

create policy "Planos activos visíveis" on public.plans
  for select to anon, authenticated using (is_active);

create policy "Subscrições: do próprio estudante" on public.subscriptions
  for select to authenticated using (user_id = auth.uid());

create policy "Pagamentos: do próprio estudante" on public.payments
  for select to authenticated using (user_id = auth.uid());

-- ============ Índices ============
create index idx_themes_discipline on public.themes(discipline_id);
create index idx_questions_discipline on public.questions(discipline_id);
create index idx_questions_theme on public.questions(theme_id);
create index idx_alternatives_question on public.question_alternatives(question_id);
create index idx_exam_questions_exam on public.exam_questions(exam_id);
create index idx_exam_attempts_user on public.exam_attempts(user_id);
create index idx_exercise_attempts_user on public.exercise_attempts(user_id);

-- ============ Dados de demonstração (claramente identificados) ============
insert into public.disciplines (name, slug, description, icon, display_order) values
  ('Matemática', 'matematica', 'Álgebra, geometria, trigonometria e funções para o exame de admissão.', 'sigma', 1),
  ('Física', 'fisica', 'Mecânica, electricidade e óptica com exercícios resolvidos.', 'atom', 2),
  ('Química', 'quimica', 'Estrutura atómica, ligações químicas e reacções.', 'flask', 3),
  ('Português', 'portugues', 'Gramática, interpretação de texto e escrita.', 'book', 4),
  ('Biologia', 'biologia', 'Célula, genética, sistemas do corpo humano e ecologia.', 'leaf', 5),
  ('Inglês', 'ingles', 'Grammar, reading e vocabulary para o exame de admissão.', 'globe', 6);

insert into public.themes (discipline_id, name, display_order)
select d.id, t.name, t.ord from public.disciplines d
join (values
  ('matematica','Álgebra',1),('matematica','Geometria',2),('matematica','Trigonometria',3),('matematica','Funções',4),
  ('fisica','Mecânica',1),('fisica','Electricidade',2),('fisica','Óptica',3),
  ('quimica','Estrutura Atómica',1),('quimica','Ligações Químicas',2),('quimica','Reacções Químicas',3),
  ('portugues','Gramática',1),('portugues','Interpretação de Texto',2),('portugues','Ortografia',3),
  ('biologia','A Célula',1),('biologia','Genética',2),('biologia','Ecologia',3),
  ('ingles','Grammar',1),('ingles','Reading',2),('ingles','Vocabulary',3)
) as t(slug, name, ord) on t.slug = d.slug;

-- Perguntas de demonstração (is_demo = true)
insert into public.questions (discipline_id, theme_id, difficulty, statement, explanation, is_demo)
select d.id, th.id, q.difficulty, q.statement, q.explanation, true
from (values
  ('matematica','Álgebra','facil','Se 2x + 6 = 14, qual é o valor de x?',
   'Subtraindo 6 aos dois lados: 2x = 8, logo x = 4.'),
  ('matematica','Álgebra','medio','Qual é o valor de 3² × 3³?',
   'Pela propriedade das potências de mesma base, 3² × 3³ = 3^(2+3) = 3⁵ = 243.'),
  ('matematica','Geometria','medio','Num triângulo rectângulo, os catetos medem 6 cm e 8 cm. Quanto mede a hipotenusa?',
   'Pelo Teorema de Pitágoras: h = √(6² + 8²) = √(36+64) = √100 = 10 cm.'),
  ('fisica','Mecânica','medio','Um carro percorre 100 m em 10 s com velocidade constante. Qual é a sua velocidade?',
   'v = Δs/Δt = 100 m / 10 s = 10 m/s.'),
  ('fisica','Electricidade','dificil','Qual é a resistência de um aparelho que, sob tensão de 220 V, consome uma corrente de 2 A?',
   'Pela Lei de Ohm: R = U/I = 220/2 = 110 Ω.'),
  ('quimica','Estrutura Atómica','facil','Quantos protões tem um átomo de oxigénio com número atómico 8?',
   'O número atómico indica a quantidade de protões no núcleo. O oxigénio tem 8 protões.'),
  ('portugues','Gramática','facil','Na frase «Os alunos estudaram muito», qual é a função de «os alunos»?',
   '«Os alunos» é o sujeito da frase: pratica a ação expressa pelo verbo estudar.'),
  ('portugues','Ortografia','facil','Qual das palavras está escrita correctamente?',
   '«Exceção» é a grafia correcta de acordo com o Acordo Ortográfico vigente para o português europeu, usado em Moçambique.'),
  ('biologia','A Célula','facil','Qual organelo é responsável pela respiração celular?',
   'A mitocôndria é responsável pela respiração celular, produzindo energia (ATP) para a célula.'),
  ('biologia','Genética','medio','Se ambos os progenitores têm genótipo Aa, qual é a probabilidade de descendentes aa?',
   'No cruzamento Aa × Aa, as combinações são AA, Aa, Aa e aa — logo 1 em 4, ou seja, 25%.'),
  ('ingles','Grammar','facil','Choose the correct sentence:','
   ''"She has lived here since 2020"'' uses the present perfect with "since" for an action that started in the past and continues.'),
  ('ingles','Vocabulary','medio','What is the meaning of the word "improve"?','
   ''To improve'' means ''to make better'' — «melhorar».'),
  ('quimica','Ligações Químicas','medio','Que tipo de ligação forma-se entre um metal e um não metal?',
   'Entre metal e não metal forma-se uma ligação iónica, com transferência de electrões.'),
  ('matematica','Funções','dificil','Qual é o domínio da função f(x) = √(x−2)?',
   'O radicando deve ser não negativo: x − 2 ≥ 0, logo x ≥ 2. O domínio é [2, +∞[.')
) as q(slug, tema, difficulty, statement, explanation)
join public.disciplines d on d.slug = q.slug
join public.themes th on th.discipline_id = d.id and th.name = q.tema;

insert into public.question_alternatives (question_id, content, is_correct, display_order)
select qu.id, a.content, a.correct, a.ord
from (values
  ('Se 2x + 6 = 14, qual é o valor de x?', 'x = 2', false, 1),
  ('Se 2x + 6 = 14, qual é o valor de x?', 'x = 4', true, 2),
  ('Se 2x + 6 = 14, qual é o valor de x?', 'x = 8', false, 3),
  ('Se 2x + 6 = 14, qual é o valor de x?', 'x = 10', false, 4),
  ('Qual é o valor de 3² × 3³?', '3⁶ = 729', false, 1),
  ('Qual é o valor de 3² × 3³?', '3⁵ = 243', true, 2),
  ('Qual é o valor de 3² × 3³?', '3⁵, mas outro valor', false, 3),
  ('Qual é o valor de 3² × 3³?', '9⁶', false, 4),
  ('Num triângulo rectângulo, os catetos medem 6 cm e 8 cm. Quanto mede a hipotenusa?', '10 cm', true, 1),
  ('Num triângulo rectângulo, os catetos medem 6 cm e 8 cm. Quanto mede a hipotenusa?', '12 cm', false, 2),
  ('Num triângulo rectângulo, os catetos medem 6 cm e 8 cm. Quanto mede a hipotenusa?', '14 cm', false, 3),
  ('Num triângulo rectângulo, os catetos medem 6 cm e 8 cm. Quanto mede a hipotenusa?', '100 cm', false, 4),
  ('Um carro percorre 100 m em 10 s com velocidade constante. Qual é a sua velocidade?', '5 m/s', false, 1),
  ('Um carro percorre 100 m em 10 s com velocidade constante. Qual é a sua velocidade?', '10 m/s', true, 2),
  ('Um carro percorre 100 m em 10 s com velocidade constante. Qual é a sua velocidade?', '20 m/s', false, 3),
  ('Um carro percorre 100 m em 10 s com velocidade constante. Qual é a sua velocidade?', '1000 m/s', false, 4),
  ('Qual é a resistência de um aparelho que, sob tensão de 220 V, consome uma corrente de 2 A?', '55 Ω', false, 1),
  ('Qual é a resistência de um aparelho que, sob tensão de 220 V, consome uma corrente de 2 A?', '110 Ω', true, 2),
  ('Qual é a resistência de um aparelho que, sob tensão de 220 V, consome uma corrente de 2 A?', '220 Ω', false, 3),
  ('Qual é a resistência de um aparelho que, sob tensão de 220 V, consome uma corrente de 2 A?', '440 Ω', false, 4),
  ('Quantos protões tem um átomo de oxigénio com número atómico 8?', '6', false, 1),
  ('Quantos protões tem um átomo de oxigénio com número atómico 8?', '8', true, 2),
  ('Quantos protões tem um átomo de oxigénio com número atómico 8?', '16', false, 3),
  ('Quantos protões tem um átomo de oxigénio com número atómico 8?', '18', false, 4),
  ('Na frase «Os alunos estudaram muito», qual é a função de «os alunos»?', 'Sujeito', true, 1),
  ('Na frase «Os alunos estudaram muito», qual é a função de «os alunos»?', 'Complemento directo', false, 2),
  ('Na frase «Os alunos estudaram muito», qual é a função de «os alunos»?', 'Predicado', false, 3),
  ('Na frase «Os alunos estudaram muito», qual é a função de «os alunos»?', 'Aposto', false, 4),
  ('Qual das palavras está escrita correctamente?', 'Exceção', true, 1),
  ('Qual das palavras está escrita correctamente?', 'Excessão', false, 2),
  ('Qual das palavras está escrita correctamente?', 'Eceção', false, 3),
  ('Qual das palavras está escrita correctamente?', 'Exceccão', false, 4),
  ('Qual organelo é responsável pela respiração celular?', 'Mitocôndria', true, 1),
  ('Qual organelo é responsável pela respiração celular?', 'Núcleo', false, 2),
  ('Qual organelo é responsável pela respiração celular?', 'Ribossoma', false, 3),
  ('Qual organelo é responsável pela respiração celular?', 'Vacúolo', false, 4),
  ('Se ambos os progenitores têm genótipo Aa, qual é a probabilidade de descendentes aa?', '0%', false, 1),
  ('Se ambos os progenitores têm genótipo Aa, qual é a probabilidade de descendentes aa?', '25%', true, 2),
  ('Se ambos os progenitores têm genótipo Aa, qual é a probabilidade de descendentes aa?', '50%', false, 3),
  ('Se ambos os progenitores têm genótipo Aa, qual é a probabilidade de descendentes aa?', '75%', false, 4),
  ('Choose the correct sentence:', 'She has lived here since 2020.', true, 1),
  ('Choose the correct sentence:', 'She live here since 2020.', false, 2),
  ('Choose the correct sentence:', 'She is living here since 2020.', false, 3),
  ('Choose the correct sentence:', 'She has lived here since three years.', false, 4),
  ('What is the meaning of the word "improve"?', 'To make better', true, 1),
  ('What is the meaning of the word "improve"?', 'To remove', false, 2),
  ('What is the meaning of the word "improve"?', 'To repeat', false, 3),
  ('What is the meaning of the word "improve"?', 'To print', false, 4),
  ('Que tipo de ligação forma-se entre um metal e um não metal?', 'Ligação iónica', true, 1),
  ('Que tipo de ligação forma-se entre um metal e um não metal?', 'Ligação covalente', false, 2),
  ('Que tipo de ligação forma-se entre um metal e um não metal?', 'Ligação metálica', false, 3),
  ('Que tipo de ligação forma-se entre um metal e um não metal?', 'Não se forma ligação', false, 4),
  ('Qual é o domínio da função f(x) = √(x−2)?', ']−∞, 2[', false, 1),
  ('Qual é o domínio da função f(x) = √(x−2)?', '[2, +∞[', true, 2),
  ('Qual é o domínio da função f(x) = √(x−2)?', 'ℝ', false, 3),
  ('Qual é o domínio da função f(x) = √(x−2)?', ']0, 2]', false, 4)
) as a(statement, content, correct, ord)
join public.questions qu on qu.statement = a.statement;

-- Simulado de demonstração
insert into public.exams (title, description, discipline_id, is_published, is_demo)
select 'Simulado de demonstração — Matemática',
       'Exemplo de simulado com perguntas de demonstração. Substitua-o no painel de administração.',
       d.id, true, true
from public.disciplines d where d.slug = 'matematica';

insert into public.exam_questions (exam_id, question_id, display_order)
select e.id, qu.id, row_number() over (order by qu.created_at)
from public.exams e
join public.questions qu on qu.discipline_id = e.discipline_id and qu.is_demo
where e.is_demo;

-- Planos (preço configurável pelo administrador)
insert into public.plans (code, name, price_mzn, description, features) values
  ('free', 'Gratuito', 0, 'Conteúdos introdutórios e exercícios limitados.', '["Exercícios introdutórios","Acesso a vídeos públicos","Histórico de resultados"]'),
  ('premium', 'Premium', 500, 'Simulados completos, todos os exercícios e recursos adicionais. O administrador pode ajustar o preço no painel.', '["Simulados completos ilimitados","Todos os exercícios por tema","Explicações com IA","Suporte prioritário"]');
